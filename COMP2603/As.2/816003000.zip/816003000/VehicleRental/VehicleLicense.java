
/**
 * Write a description of class VehicleLicense here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface VehicleLicense
{   
    public boolean isExpired();
    public String getLicenseHolderName();
    public int getLicenseHolderAge();
    public String getLicenseRegistrationNo();
    public String getLicenseType();
}
