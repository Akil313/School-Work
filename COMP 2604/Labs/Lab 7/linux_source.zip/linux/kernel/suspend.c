/*
 * linux/kernel/suspend.c
 *
 * This file is to realize architecture-independent
 * machine suspend feature using pretty near only high-level routines
 *
 * Copyright (C) 1998-2001 Gabor Kuti <seasons@fornax.hu>
 * Copyright (C) 1998,2001,2002 Pavel Machek <pavel@suse.cz>
 * Copyright (C) 2002 Florent Chabaud <fchabaud@free.fr>
 *
 * I'd like to thank the following people for their work:
 * 
 * Pavel Machek <pavel@ucw.cz>:
 * Modifications, defectiveness pointing, being with me at the very beginning,
 * suspend to swap space, stop all tasks. Port to 2.4.18-ac and 2.5.17.
 *
 * Steve Doddi <dirk@loth.demon.co.uk>: 
 * Support the possibility of hardware state restoring.
 *
 * Raph <grey.havens@earthling.net>:
 * Support for preserving states of network devices and virtual console
 * (including X and svgatextmode)
 *
 * Kurt Garloff <garloff@suse.de>:
 * Straightened the critical function in order to prevent compilers from
 * playing tricks with local variables.
 *
 * Andreas Mohr <a.mohr@mailto.de>
 *
 * Alex Badea <vampire@go.ro>:
 * Fixed runaway init
 *
 * Jeff Snyder <je4d@pobox.com>
 * ACPI patch
 *
 * Nathan Friess <natmanz@shaw.ca>
 * Some patches.
 *
 * Nigel Cunningham <ncunningham@clear.net.nz>
 * Nice display and other patches.
 *
 * More state savers are welcome. Especially for the scsi layer...
 *
 * For TODOs,FIXMEs also look in Documentation/swsusp.txt
 */

#include <linux/module.h>
#include <linux/mm.h>
#include <linux/swapctl.h>
#include <linux/suspend.h>
#include <linux/proc_fs.h>
#include <linux/smp_lock.h>
#include <linux/file.h>
#include <linux/utsname.h>
#include <linux/version.h>
#include <linux/compile.h>
#include <linux/delay.h>
#include <linux/reboot.h>
#include <linux/init.h>
#include <linux/locks.h>
#include <linux/vt_kern.h>
#include <linux/bitops.h>
#include <linux/interrupt.h>
#include <linux/kbd_kern.h>
#include <linux/keyboard.h>
#include <linux/spinlock.h>
#include <linux/genhd.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/blk.h>
#include <linux/swap.h>
#include <linux/pm.h>
#include <linux/raid/md.h>
#include <linux/selection.h>
#include <linux/console_struct.h>
#include <linux/console.h>

#include <asm/uaccess.h>
#include <asm/mmu_context.h>
#include <asm/pgtable.h>
#include <asm/io.h>
#include <asm/mtrr.h>

unsigned char software_suspend_enabled = 0;
unsigned int suspend_task = 0;
/*
 * Poll the swsusp state every second
 */
#define SWSUSP_CHECK_TIMEOUT	(HZ)

#define SUSPEND_CONSOLE	(MAX_NR_CONSOLES-1)
#if 0 || !defined(CONFIG_VT) || !defined(CONFIG_VT_CONSOLE)
# undef SUSPEND_CONSOLE
#endif

#define TIMEOUT	(6 * HZ)			/* Timeout for stopping processes */
#define ADDRESS(x) ((unsigned long) phys_to_virt(((x) << PAGE_SHIFT)))

extern int C_A_D;

/* References to section boundaries */
extern char _text, _etext, _edata, __bss_start, _end;
extern char __nosave_begin, __nosave_end;

extern int console_loglevel;
static int is_head_of_free_region(struct page * page);
static void generate_free_page_map(void);
extern inline void signal_wake_up(struct task_struct *t);
asmlinkage long sys_sched_yield(void);
asmlinkage void sys_sync(void);	/* it's really int */
extern void ide_disk_unsuspend(int);
extern void ide_disk_suspend(void);
extern kdev_t name_to_kdev_t(char *line) __init;
extern void vt_console_print(struct console *co, const char * b, unsigned count);
extern void reset_terminal(int currcons, int do_clear);
extern void hide_cursor(int currcons);
extern void free_suspend_cache_page(void);
/* Locks */
spinlock_t suspend_pagedir_lock __nosavedata = SPIN_LOCK_UNLOCKED;

/* Variables to be preserved over suspend */
static int new_loglevel = 7;
static int orig_loglevel = 0;
static int orig_fgconsole;
static int pagedir_order_check;
static int pageset1_size_check;

static int resume_status = 0;
static char resume_file[256] = "";			/* For resume= kernel option */
static kdev_t resume_device;
/* Local variables that should not be affected by save */
static unsigned int pageset1_size __nosavedata = 0;

static int pm_suspend_state = 0;

/* Suspend pagedir is allocated before final copy, therefore it
   must be freed after resume 

   Warning: this is evil. There are actually two pagedirs at time of
   resume. One is "pagedir_save", which is empty frame allocated at
   time of suspend, that must be freed. Second is "pagedir_nosave", 
   allocated at time of resume, that travels through memory not to
   collide with anything.
 */
static suspend_pagedir_t *pagedir_nosave __nosavedata = NULL;
static suspend_pagedir_t *pagedir_save;
static int pagedir_order __nosavedata = 0;

#ifdef SUSPEND_CONSOLE
static int orig_kmsg;
static int barwidth = 0, barposn = -1, newbarposn = 0, lastpercentage = 0;
#define suspend_console (struct console *) NULL	/* Used in some console calls - obsolete parameter */
#endif

struct link {
	char dummy[PAGE_SIZE - sizeof(swp_entry_t)];
	swp_entry_t next;
};

union diskpage {
	union swap_header swh;	/* swh.magic is the only member used */
	struct link link;
	struct suspend_header sh;
};

union p_diskpage {
	union diskpage *pointer;
	char *ptr;
        unsigned long address;
};

/*
 * XXX: We try to keep some more pages free so that I/O operations succeed
 * without paging. Might this be more?
 */
#define PAGES_FOR_IO	512

#define name_suspend "Suspend Machine:  "
#define name_resume  "Resume Machine:   "
#define swsusp_version "beta 17"
#define name_swsusp  "Swsusp " swsusp_version ":   "
#define console_suspend "S U S P E N D   T O   D I S K"
#define console_resume "R E S U M E   F R O M   D I S K"
static int now_resuming = 0;
/*
 * Debug
 */
#define	DEBUG_DEFAULT	1	/* activate debugging setting in /proc/sys/kernel/swsusp
				   Commenting out will save very few cycles and prevent from
				   debuugging new hardware. */
/* first status register */
#define SUSPEND_PENDING (swsusp_state[0] & 0x1)
#define SUSPEND_ABORTING (swsusp_state[0] & 0x2)
/* second status register */
#define SUSPEND_REBOOT  (swsusp_state[1] & 0x1)
#define SUSPEND_FREEMEM (swsusp_state[1] & 0x2)
#define SUSPEND_PAUSE (swsusp_state[1] & 0x4)
#define SUSPEND_NOPAGESET2 (swsusp_state[1] & 0x8)
#define SUSPEND_PAUSE_BETWEEN_STEPS (swsusp_state[1] & 0x10)
/* third status register */
#define SUSPEND_DEBUG   	0x1
#define SUSPEND_PROGRESS   	0x2
#define SUSPEND_VERBOSE   	0x4
#define SUSPEND_SLOW		0x8
#define SUSPEND_DEBUG_MAP	0x10
/* fourth status register */
#define SUSPEND_LOWMEM   (swsusp_state[3] < 0 ? 0 : (swsusp_state[3] > 100 ? 100 : swsusp_state[3]))
/* fifth status register */
#define STAGE_FREEZER 		0x1
#define STAGE_EAT_MEMORY 	0x2
#define STAGE_MARK_PAGESET2 	0x4
#define STAGE_WRITE_PAGESETS 	0x8
#define STAGE_FREE_PAGES 	0x10

#ifdef DEBUG_DEFAULT
#define PRINTTHRESH 3		/* Number of lines at the start/end of pagesets to show */
static int currentstage = 0;	/* Current stage (STAGEPRINT macro) */
#define STAGEPRINT ((currentstage == 0) || (swsusp_state[4] & currentstage))
# define PRINTK(mask, f, a...)	((((mask) & swsusp_state[2]) && STAGEPRINT) ? printk(f, ## a):0)
# define MDELAY(a) 		if (swsusp_state[2] & SUSPEND_SLOW)  mdelay(a); else
int swsusp_state[5] = {0,	/* when set to 1 swsusp_mainloop activates software_suspend
				   bit 0: off = normal state, on = suspend required
				   bit 1: aborting suspend
				*/
		       0,	/* action parameter:
				   bit 0: off = halt, on = reboot 
				   bit 1: off = eatmem, on = freemem
				   bit 2: pause between steps
				   bit 3: no pageset2
				*/
		       SUSPEND_PROGRESS,
				/* debugging parameter is an OR of flags:
				   bit 0: debugging messages
				   bit 1: display progression
				   bit 2: very verbose mode
				   bit 3: slow down process
				   bit 4: debug map
				   This value can also be set by swsusp_dbg= kernel boot option.
				*/
		       25,	/* percent of pages not to free using memeat */
		       0};	/* which section to debug */
#else
# define PRINTK(f, a...)
# define MDELAY(a)
int swsusp_state[5] = {0,0,-1,25,0};	/* see above for signification of values */
#endif

// |= 0x2 is the flag that we are aborting the process.
#define abort_suspend(f, a...) do { \
	printk(f, ## a); \
	swsusp_state[0] |= 0x2; \
} while(0)

static void generate_free_page_map(void) 
{
	int i, loop;
	struct page * page;
	pg_data_t *pgdat = pgdat_list;
	unsigned type;
	unsigned long flags;
	
	for(i=0; i < max_mapnr; i++)
		ClearPageFree(mem_map+i);

	for (type=0;type < MAX_NR_ZONES; type++) {
		zone_t *zone = pgdat->node_zones + type;
		int order = MAX_ORDER - 1;
		free_area_t *area;
		struct list_head *head, *curr;
		spin_lock_irqsave(&zone->lock, flags);

		PRINTK(SUSPEND_DEBUG_MAP,"Zone %d\n", type);
		do {
			int first_entry = 1;
			area = zone->free_area + order;
			head = &area->free_list;
			curr = head;

			PRINTK(SUSPEND_DEBUG_MAP,"- Order %d: ", order);

			for(;;) {
				if(!curr) {
//					printk(KERN_ERR name_suspend "FIXME: this should not happen but it does!!!");
					break;
				}
				if (first_entry) 
					first_entry--;
				else {
					page = list_entry(curr, struct page, list);
					PRINTK(SUSPEND_DEBUG_MAP,"%lx ", page);
					for(loop=0; loop < (1 << order); loop++)
						SetPageFree(page+loop);

				}

				curr = curr->next;
				if (curr == head)
					break; 				
			}
			PRINTK(SUSPEND_DEBUG_MAP,"\n");
		} while(order--);
		spin_unlock_irqrestore(&zone->lock, flags);
		PRINTK(SUSPEND_DEBUG_MAP,"\n");
	}
	PRINTK(SUSPEND_VERBOSE,"At end, free pages is %d\n", nr_free_pages());
}

static int is_head_of_free_region(struct page * page)
{
	struct page * posn = page;

	while (((posn-mem_map) < max_mapnr) && (PageFree(posn))) 
		posn++;
	return (posn - page);
}

struct page * last_suspend_cache_page;		/* Pointer to the last cache page */

#ifdef SUSPEND_CONSOLE 
#define WAIT_FOR_SHIFT { \
	if (SUSPEND_PAUSE) { \
		int i; \
		unsigned int currcons = fg_console; \
		printk("\r"); \
		for (i=0; i < (video_num_columns - 2); i++) \
			vt_console_print(suspend_console, " ", 1); \
		printk("\r"); \
		for (i=0; i < ((video_num_columns - 49) / 2); i++) \
			vt_console_print(suspend_console, " ", 1); \
		printk("Waiting for you to press and release SHIFT before continuing.\n"); \
		while (!(shift_state & (1 << KG_SHIFT))) \
			schedule(); \
		while ((shift_state & (1 << KG_SHIFT))) \
			schedule(); \
	} \
}
#else
#define WAIT_FOR_SHIFT  do { } while (0)
#endif

#define BUFFER_BUSY_BITS	((1<<BH_Dirty) | (1<<BH_Lock))
#define buffer_busy(bh)		(atomic_read(&(bh)->b_count) | ((bh)->b_state & BUFFER_BUSY_BITS))

#define BREAD_BUFFER_HEAD(pos) \
	bh = bread(resume_device, pos/PAGE_SIZE, PAGE_SIZE); \
	if (!bh || (!bh->b_data)) { \
		return -EIO; \
	}

#define BFREE \
	if (!buffer_busy(bh)) \
		try_to_free_buffers(bh->b_page, __GFP_FAST); \
	free_suspend_cache_page();
	
static unsigned long copybuff = 0;

static void prepare_status(char * action)
{
#if defined(SUSPEND_CONSOLE)
	char posn[2];
	unsigned int currcons = fg_console;

	if (swsusp_state[2] != SUSPEND_PROGRESS)
		return;
	
	hide_cursor(fg_console);

	barwidth = (video_num_columns - (video_num_columns / 2) - 1);
	barposn = 0;

	/* Print version */
	posn[0] = (char) (0);
	posn[1] = (char) (video_num_lines);
	putconsxy(fg_console, posn);
	vt_console_print(suspend_console, name_swsusp, strlen(name_swsusp));

	/* Print header */
	posn[0] = (char) ((video_num_columns - 29) / 2);
	posn[1] = (char) ((video_num_lines / 3) -4);
	putconsxy(fg_console, posn);
	if (now_resuming)
		vt_console_print(suspend_console, console_resume, strlen(console_resume));
	else
		vt_console_print(suspend_console, console_suspend, strlen(console_suspend));
		
	/* Print action */
	posn[0] = (char) (video_num_columns / 4);
	posn[1] = (char) (video_num_lines / 3);
	putconsxy(fg_console, posn);
	
	/* Blank out previous contents of line - assumes text length <= bar width */
	for (barposn = 0; barposn < barwidth; barposn++) 
		vt_console_print(suspend_console, " ", 1);
	
	putconsxy(fg_console, posn);
	vt_console_print(suspend_console, action, strlen(action)); 

	/* Draw left bracket of progress bar. */
	posn[1]++;
	putconsxy(fg_console, posn);
	vt_console_print(suspend_console, "[", 1);

	/* Draw right bracket of progress bar. */
	posn[0] = (char) (video_num_columns - (video_num_columns / 4));
	putconsxy(fg_console, posn);
	vt_console_print(suspend_console, "]", 1);

	/* Position at start of progress */
	posn[0] = (char) (video_num_columns / 4 + 1);
	putconsxy(fg_console, posn);

	/* Clear bar */
	for (barposn = 0; barposn < barwidth; barposn++)
		vt_console_print(suspend_console, " ", 1);
	putconsxy(fg_console, posn);

	barposn = 0;
	lastpercentage = 0;
	hide_cursor(fg_console);
	MDELAY(1000);
#endif
}

static void update_status(int percentage)
{
#if defined(SUSPEND_CONSOLE)
	if (swsusp_state[2] != SUSPEND_PROGRESS)
		return;
	
	if (percentage < 0)
		percentage = 0;
	if (percentage > 100)
		percentage = 100;

	newbarposn = (int) (percentage * barwidth / 100);
	
	if (newbarposn == barposn)
		return;       

	lastpercentage = percentage;
	
	for (; barposn < newbarposn; barposn++)
		vt_console_print(suspend_console, "-", 1);
	barposn = newbarposn;
	hide_cursor(fg_console);
#endif
}
/*
 * Refrigerator and related stuff
 */

#define INTERESTING(p) \
			/* We don't want to touch kernel_threads..*/ \
			if (p->flags & PF_IOTHREAD) \
				continue; \
			if (p == current) \
				continue; \
			if (p->state == TASK_ZOMBIE) \
				continue;

/* Refrigerator is place where frozen processes are stored :-). */
void refrigerator(unsigned long flag)
{
	/* You need correct to work with real-time processes.
	   OTOH, this way one process may see (via /proc/) some other
	   process in stopped state (and thereby discovered we were
	   suspended. We probably do not care. 
	 */
	long save;
	save = current->state;
	current->state = TASK_STOPPED;
	PRINTK(SUSPEND_DEBUG, "=");
	PRINTK(SUSPEND_VERBOSE, "%s entered refrigerator (%lx)\n", current->comm, flag);
	current->flags &= ~PF_FREEZE;
	if (flag)
		flush_signals(current); /* We have signaled a kernel thread, which isn't normal behaviour
					   and that may lead to 100%CPU sucking because those threads
					   just don't manage signals. */
	current->flags |= PF_FROZEN;
	while (current->flags & PF_FROZEN)
		schedule();
	PRINTK(SUSPEND_VERBOSE, "%s left refrigerator (%lx)\n", current->comm, flag);
	current->state = save;
}

/* 0 = success, else # of processes that we failed to stop */
static int freeze_processes(void)
{
	int todo, start_time;
	struct task_struct *p;
	
	PRINTK(SUSPEND_DEBUG, name_suspend "Stopping tasks\n" );
	prepare_status("Freezing processes...");

	suspend_task = current->pid;

	start_time = jiffies;
	do {
		todo = 0;
		read_lock(&tasklist_lock);
		for_each_task(p) {
			unsigned long flags;
			INTERESTING(p);
			if (p->flags & PF_FROZEN)
				continue;
			if (p->state == TASK_STOPPED) {	/* this task is a stopped but not frozen one */
				/* FIXME: what if a task is waken between this point and suspension ? */
				p->flags |= PF_IOTHREAD;
				PRINTK(SUSPEND_DEBUG,"+");
				PRINTK(SUSPEND_VERBOSE,"%s is already stopped\n", p->comm);
				continue;
			}
			/* FIXME: smp problem here: we may not access other process' flags
			   without locking */
			p->flags |= PF_FREEZE;
			spin_lock_irqsave(&p->sigmask_lock, flags);
			signal_wake_up(p);
			spin_unlock_irqrestore(&p->sigmask_lock, flags);
			todo++;
		}
		read_unlock(&tasklist_lock);
		yield();
		if (time_after(jiffies, start_time + TIMEOUT)) {
			PRINTK(SUSPEND_DEBUG,"\n");
			printk(KERN_ERR name_suspend " stopping tasks failed (%d tasks remaining)\n", todo );
			return todo;
		}
	} while(todo);
	
	PRINTK(SUSPEND_DEBUG,"|\n");
	return 0;
}

static void thaw_processes(void)
{
	struct task_struct *p;

	PRINTK(SUSPEND_DEBUG, name_resume "Restarting tasks\n");
	read_lock(&tasklist_lock);
	for_each_task(p) {
		if ((p->flags & PF_IOTHREAD)
		   && (p->state == TASK_STOPPED)) { /* This is a previously stopped job */
			p->flags &= ~PF_IOTHREAD; /* we assume here that a kernel thread with PF_IOTHREAD
						     is *never* stopped */
			PRINTK(SUSPEND_DEBUG, "+");
			PRINTK(SUSPEND_VERBOSE, KERN_INFO name_resume " %s was stopped\n", p->comm );
			continue; /* we don't want to wake up this job */
		}
		INTERESTING(p);
		
		if (p->flags & PF_FROZEN) {
	        	p->flags &= ~PF_FROZEN;
			PRINTK(SUSPEND_DEBUG, "-");
		} else
			printk(KERN_INFO " Strange, %s not stopped\n", p->comm );
		wake_up_process(p);
	}
	read_unlock(&tasklist_lock);
	suspend_task = 0;
	PRINTK(SUSPEND_DEBUG, "|\n");
	MDELAY(500);
}

/*
 * Saving part...
 */

static __inline__ int fill_suspend_header(struct suspend_header *sh)
{
	memset((char *)sh, 0, sizeof(*sh));

	sh->version_code = LINUX_VERSION_CODE;
	sh->num_physpages = num_physpages;
	strncpy(sh->machine, system_utsname.machine, 65);
	strncpy(sh->version, system_utsname.version, 65);
	sh->num_cpus = smp_num_cpus;
	sh->page_size = PAGE_SIZE;
	sh->suspend_pagedir = pagedir_nosave;
	if (pagedir_save != pagedir_nosave) {
		abort_suspend("Pagedir_save != Pagedir_nosave!");
		return 1;
	}
	sh->pageset1_size = pageset1_size;
        sh->param0 = swsusp_state[0];
        sh->param1 = swsusp_state[1];
        sh->param2 = swsusp_state[2];
        sh->param3 = swsusp_state[3];
	sh->param4 = swsusp_state[4];
	/* TODO: needed? mounted fs' last mounted date comparison
	 * [so they haven't been mounted since last suspend.
	 * Maybe it isn't.] [we'd need to do this for _all_ fs-es]
	 */
	return 0;
}

/*
 * This is our sync function. With this solution we probably won't sleep
 * but that should not be a problem since tasks are stopped..
 */

static void do_suspend_sync(void)
{
	while (1) {
		run_task_queue(&tq_disk);
		if (!TQ_ACTIVE(tq_disk))
			break;
		printk(KERN_ERR "Hm, tq_disk is not empty after run_task_queue\n");
	}
}

/* We memorize in swapfile_used what swap devices are used for suspension */
#define SWAPFILE_UNUSED    0
#define SWAPFILE_SUSPEND   1	/* This is the suspending device */
#define SWAPFILE_IGNORED   2	/* Those are other swap devices ignored for suspension */

static unsigned short swapfile_used[MAX_SWAPFILES];
static unsigned short root_swap;
#define MARK_SWAP_SUSPEND 0
#define MARK_SWAP_RECOVER 1
#define MARK_SWAP_RESUME 2

static inline int sync_page(struct page *page)
{
	struct address_space *mapping = page->mapping;

	if (mapping && mapping->a_ops && mapping->a_ops->sync_page)
		return mapping->a_ops->sync_page(page);
	return 0;
}

static int rw_swap_page_nofree(int rw, swp_entry_t entry, union p_diskpage cur)
{
	struct page *page;

	page=virt_to_page(cur.address);
	lock_page(page);
	PRINTK(SUSPEND_DEBUG, "rw(page:%p) ",page);
	rw_swap_page_nolock_norfree(rw, entry, cur.ptr);
	sync_page(page);
	if(!Page_Uptodate(page)) {
		abort_suspend("Page not up-to-date in rw_swap_page_nofree!\n");
		return 1;
	}
	return 0;
}

static int rw_swap_page_sync(int rw, swp_entry_t entry, union p_diskpage cur)
{
	struct page *page;
	//unsigned long dummy1;
	//struct inode *dummy2;

	page=virt_to_page(cur.address);	
	lock_page(page);
	//get_swaphandle_info(entry, &dummy1, &suspend_device, &dummy2);
	rw_swap_page_nolock(rw, entry, cur.ptr);
	sync_page(page);
	if(!Page_Uptodate(page)) {
		abort_suspend("Page not up-to-date in rw_swap_page_nofree!\n");
		return 1;
	}
	return 0;
}

static void mark_swapfiles(swp_entry_t prev, int mode)
{
	swp_entry_t entry;
	union p_diskpage cur;

	cur.address = copybuff;
	/* XXX: this is dirty hack to get first page of swap file */
	entry = SWP_ENTRY(root_swap, 0);
	if (rw_swap_page_sync(READ, entry, cur)) {
		return;
	}

	switch(mode) {
	case MARK_SWAP_RESUME:
		if (!memcmp("SUSP1R",cur.pointer->swh.magic.magic,6))
			memcpy(cur.pointer->swh.magic.magic,"SWAP-SPACE",10);
		else if (!memcmp("SUSP2R",cur.pointer->swh.magic.magic,6))
			memcpy(cur.pointer->swh.magic.magic,"SWAPSPACE2",10);
		else printk(name_resume "Unable to find suspended-data signature (%.10s - misspelled?\n", 
			    cur.pointer->swh.magic.magic);
		break;
	case MARK_SWAP_RECOVER:
		if (!memcmp("SUSP1R",cur.pointer->swh.magic.magic,6))
			memcpy(cur.pointer->swh.magic.magic,"SWAP-SPACE",10);
		else if (!memcmp("SUSP2R",cur.pointer->swh.magic.magic,6))
			memcpy(cur.pointer->swh.magic.magic,"SWAPSPACE2",10);
	  	else if ((!memcmp("SWAP-SPACE",cur.pointer->swh.magic.magic,10))
			 &&(!memcmp("SWAPSPACE2",cur.pointer->swh.magic.magic,10))) {
			abort_suspend("\nSwapspace is altered (%.10s)\n", cur.pointer->swh.magic.magic);
			return;
		}
		break;
	case MARK_SWAP_SUSPEND:
	  	if ((!memcmp("SWAP-SPACE",cur.pointer->swh.magic.magic,10)))
		  	memcpy(cur.pointer->swh.magic.magic,"SUSP1R....",10);
		else if ((!memcmp("SWAPSPACE2",cur.pointer->swh.magic.magic,10)))
			memcpy(cur.pointer->swh.magic.magic,"SUSP2R....",10);
		else {
			abort_suspend("\nSwapspace is not swapspace (%.10s)\n", cur.pointer->swh.magic.magic);
			return;
		}
		cur.pointer->link.next = prev; /* prev is the first/last swap page of the resume area */
		/* link.next lies *no more* in last 4 bytes of magic */
		break;
	}
	rw_swap_page_sync(WRITE, entry, cur);
}

static void read_swapfiles(void) /* This is called before saving image */
{
	int i, len;
	
	len=strlen(resume_file);
	root_swap = 0xFFFF;
	
	swap_list_lock();
	for(i=0; i<MAX_SWAPFILES; i++) {
		if (swap_info[i].flags == 0) {
			swapfile_used[i]=SWAPFILE_UNUSED;
		} else {
			if (!len) {
	    			printk("resume= option should be used to set suspend device" );
				if (root_swap == 0xFFFF) {
					swapfile_used[i] = SWAPFILE_SUSPEND;
					root_swap = i;
				} else
					swapfile_used[i] = SWAPFILE_IGNORED;				  
			} else {
	  			/* we ignore all swap devices that are not the resume_file */
				if (resume_device == swap_info[i].swap_device) {
					swapfile_used[i] = SWAPFILE_SUSPEND;
					root_swap = i;
				} else {
					PRINTK(SUSPEND_DEBUG, name_suspend "device %s (%x != %x) ignored\n", swap_info[i].swap_file->d_name.name, swap_info[i].swap_device, resume_device);
				  	swapfile_used[i] = SWAPFILE_IGNORED;
				}
			}
		}
	}
	swap_list_unlock();
}

static void lock_swapdevices(void) /* This is called after saving image so modification
				      will be lost after resume... and that's what we want. */
{
	int i;

	swap_list_lock();
	for(i = 0; i< MAX_SWAPFILES; i++)
		if (swapfile_used[i] == SWAPFILE_IGNORED) {
			swap_info[i].flags ^= 0xFF; /* we make the device unusable. A new call to
						       lock_swapdevices can unlock the devices. */
		}
	swap_list_unlock();
}

static int write_suspend_image(void)
{
	int i, len, *ptr;
	swp_entry_t entry, prev = { 0 };
	int nr_pgdir_pages = SUSPEND_PD_PAGES(pageset1_size);
	union p_diskpage cur, buffer;

#define abort_and_exit(f, a...) do { \
			abort_suspend(f, ## a); \
			return -1; \
	} while(0)

	buffer.address = copybuff;
	PRINTK(SUSPEND_DEBUG, name_suspend "Writing data to swap (%d pages)\n", pageset1_size);
	prepare_status("Writing suspend image...");

	for (i=0; i<pageset1_size; i++) {
		if (!(i%100))
			PRINTK(SUSPEND_DEBUG, ".");
		update_status((int) (i * 100 / (pageset1_size+nr_pgdir_pages+2)));

		entry = get_swap_page();
		if (!entry.val)
			abort_and_exit("Not enough swapspace when writing data.\n");
		if (swapfile_used[SWP_TYPE(entry)] != SWAPFILE_SUSPEND)
			abort_and_exit("Page %d: not enough swapspace on suspend device.\n", i);
/* CBD: pagedir is a dirty hack. Here we advance by i*sizeof(suspend_pagedir_t) and we fill with adresses */
		cur.address = (pagedir_nosave+i)->address3;
		if (rw_swap_page_sync(WRITE, entry, cur))
			return -1;
		(pagedir_nosave+i)->swap_address1 = entry;
#ifdef DEBUG_DEFAULT
		if (i < PRINTTHRESH || ((i + PRINTTHRESH) > pageset1_size))
			PRINTK(SUSPEND_VERBOSE, "!%d! [1]%lx -> [sw]%lx.\n", i, (pagedir_nosave+i)->address1, entry.val);
#endif
	}
	PRINTK(SUSPEND_DEBUG, "|\n");
	PRINTK(SUSPEND_DEBUG, name_suspend "Writing pagedir (%d pages)\n", nr_pgdir_pages);
	for (i=0; i<nr_pgdir_pages; i++) {
/* CBD: Here we advance by a PAGE_SIZE because (union diskpage).link is of that maximal size */
		cur.pointer = (union diskpage *)pagedir_nosave + i;
		if (cur.ptr != (((char *) pagedir_nosave) + i*PAGE_SIZE))
			abort_and_exit("cur.ptr != Pagedir_nosave + i * PAGESIZE! \n");
		PRINTK(SUSPEND_DEBUG, ".");
		update_status((int) ((i+pageset1_size) * 100 / (pageset1_size+nr_pgdir_pages+2)));
		entry = get_swap_page();
		if (!entry.val)
			abort_and_exit("Not enough swapspace when writing pgdir\n");		
		if (swapfile_used[SWP_TYPE(entry)] != SWAPFILE_SUSPEND)
			abort_and_exit("Not enough swapspace for pagedir on suspend device\n");
		if (sizeof(swp_entry_t) != sizeof(long))
			abort_and_exit("Size of swp_entry_t != size of long in write_pagedir_and_suspend_header!\n");
		if (PAGE_SIZE % sizeof(struct pbe))
			abort_and_exit("Page size (%ld) mod size of struct pbe (%d) is not 0 (%ld) in write_pagedir_and_suspend_header!\n", PAGE_SIZE, sizeof(struct pbe), PAGE_SIZE % sizeof(struct pbe));
		cur.pointer->link.next = prev;				
		if (rw_swap_page_nofree(WRITE, entry, cur))
			return -1;
		prev = entry;
	}
	PRINTK(SUSPEND_DEBUG, "H");
#ifdef SOFTWARE_SUSPEND_MTRR
	ptr = mtrr_suspend();
	if(ptr)
		len = *ptr;
	else
#endif
	{
		len = 4;	/* we need to put a zero */
		ptr = NULL;
	}
	if (len + sizeof(struct suspend_header) > PAGE_SIZE-sizeof(swp_entry_t))
		abort_and_exit("Size of suspend header too big!\n");
	if (sizeof(union diskpage) != PAGE_SIZE)
		abort_and_exit("Size of a disk page is not PAGE_SIZE!\n");
	entry = get_swap_page();
	if (!entry.val)
		abort_and_exit("Not enough swapspace when writing header!\n");
	if (swapfile_used[SWP_TYPE(entry)] != SWAPFILE_SUSPEND)
		abort_and_exit("Not enough swapspace for header on suspend device!\n" );

	cur = buffer;
	if (fill_suspend_header(&(cur.pointer->sh)))
		abort_and_exit("Out of memory while writing header!\n");
	if(ptr)
		memcpy(cur.ptr+sizeof(struct suspend_header), ptr, len);
	else {
		len = 0;
		ptr = &len;
		memcpy(cur.ptr+sizeof(struct suspend_header), ptr, sizeof(int));
	}	
	cur.pointer->link.next = prev;

	if (rw_swap_page_nofree(WRITE, entry, cur))
		return -1;
	prev = entry;

	PRINTK(SUSPEND_DEBUG, "S");
	update_status((int) ((nr_pgdir_pages+pageset1_size+1) * 100 / (pageset1_size+nr_pgdir_pages+2)));
	mark_swapfiles(prev, MARK_SWAP_SUSPEND);
	if (SUSPEND_ABORTING)
		return -1;
	PRINTK(SUSPEND_DEBUG, "|\n");
	update_status(100);

	MDELAY(1000);
	return 0;
}

/* if pagedir_p != NULL it also copies the counted pages */
static int count_and_copy_data_pages(struct pbe *pagedir_p)
{
	int chunk_size;
	int pageset1_size = 0;
	int loop;
	
	if (pagedir_p)
		prepare_status("Copying pages...");
	else
		prepare_status("Counting pages...");
	generate_free_page_map();
	if (max_mapnr != num_physpages) {
		abort_suspend("mapnr is not expected");
		return 0;
	}
	for (loop = 0; loop < max_mapnr; loop++) {
		update_status(loop * 100 / max_mapnr);
		if (PageHighMem(mem_map+loop)) {
			abort_suspend("Swsusp not supported on highmem boxes. Send 1GB of RAM to <pavel@ucw.cz> and try again ;-).");
			return 0;
		}
		if (!PageReserved(mem_map+loop)) {
			if (PageNosave(mem_map+loop))
				continue;

			if ((chunk_size=is_head_of_free_region(mem_map+loop))!=0) {
				loop += chunk_size - 1;
				continue;
			}
		} else if (PageReserved(mem_map+loop)) {
			if (PageNosave(mem_map+loop)) {
				abort_suspend("Reserved page marked nosave!\n");
				return 0;
			}
			/*
			 * Just copy whole code segment. Hopefully it is not that big.
			 */
			if (ADDRESS(loop) >= (unsigned long)
				&__nosave_begin && ADDRESS(loop) < 
				(unsigned long)&__nosave_end) {
				PRINTK(SUSPEND_VERBOSE, name_suspend "[nosave %lx]\n", ADDRESS(loop));
				continue;
			}
			/* Hmm, perhaps copying all reserved pages is not too healthy as they may contain 
			   critical bios data? */
		} else BUG();

		pageset1_size++;
		if (pagedir_p) {
			pagedir_p->address1 = ADDRESS(loop);
			copy_page(pagedir_p->address3, pagedir_p->address1);
			pagedir_p++;
		}
	}
	update_status(100);
	return pageset1_size;
}

static void free_suspend_pagedir(suspend_pagedir_t *pagedir)
{
	struct page *page = mem_map;
	int i;
	unsigned long this_pagedir, this_pagedir_end;

	this_pagedir = (unsigned long) pagedir;
	this_pagedir_end  = this_pagedir + (PAGE_SIZE << pagedir_order);

	for(i=0; i < num_physpages; i++, page++) {
		if (!PageTestandClearNosave(page))
			continue;

		if (ADDRESS(i) >= this_pagedir && ADDRESS(i) < this_pagedir_end)
			continue; /* old pagedir gets freed in one */
		
		free_page(ADDRESS(i));
	}
	free_pages(this_pagedir, pagedir_order);
}

static suspend_pagedir_t *create_suspend_pagedir(int pageset1_size)
{
	int i;
	suspend_pagedir_t *pagedir;
	struct pbe *p;
	struct page *page;

	pagedir_order = get_bitmask_order(SUSPEND_PD_PAGES(pageset1_size));

	p = pagedir = (suspend_pagedir_t *)__get_free_pages(GFP_ATOMIC, pagedir_order);
	if (!pagedir)
		return NULL;

	page = virt_to_page(pagedir);
	for(i=0; i < 1<<pagedir_order; i++)
		PageSetNosave(page++);
		
	while(pageset1_size--) {
		p->address3 = get_free_page(GFP_ATOMIC);
		if(!p->address3) {
			panic("oom");
			free_suspend_pagedir(pagedir);
			return NULL;
		}
		PageSetNosave(virt_to_page(p->address3));
		p->address1 = 0;
		p++;
	}
	return pagedir;
}

static int prepare_suspend_console(void)
{
	if ((!swsusp_state[2]) && (!swsusp_state[4]))  /* No output should be produced. 
							  It would be good if we could tell X to 
							  refresh the display at resume if it's 
							  running on the  current VT. (In a script? */
		return 0;

	orig_loglevel = console_loglevel;
	console_loglevel = new_loglevel;

#ifdef CONFIG_VT
	orig_fgconsole = fg_console;
#ifdef SUSPEND_CONSOLE
	if (vc_allocate(SUSPEND_CONSOLE))
	  /* we can't have a free VC for now. Too bad,
	   * we don't want to mess the screen for now. */
		return 1;

	set_console (SUSPEND_CONSOLE);
	if (vt_waitactive(SUSPEND_CONSOLE)) {
		PRINTK(SUSPEND_DEBUG, "Can't switch virtual consoles.");
		return 1;
	}
	reset_terminal(SUSPEND_CONSOLE, 1);
	orig_kmsg = kmsg_redirect;
	kmsg_redirect = SUSPEND_CONSOLE;
	prepare_status("");
# endif
#endif
	return 0;
}

static void restore_console(void)
{
	if ((!swsusp_state[2]) && (!swsusp_state[4])) /* No output should have been produced */
		return;

	console_loglevel = orig_loglevel;
#ifdef SUSPEND_CONSOLE
	kmsg_redirect = orig_kmsg;
	set_console (orig_fgconsole);
#endif
	return;
}

static int prepare_suspend_processes(void)
{
	if (freeze_processes()) {
		PRINTK(SUSPEND_DEBUG, name_suspend "Not all processes stopped!\n");
		thaw_processes();
		return 1;
	}
	sys_sync();
	return 0;
}

/*
 *	Free as much memory as possible
 */

static void **eaten_memory = NULL;

static int eat_memory(void)
{
	int i = 0;
	int j, max;
	struct sysinfo meminfo;
	void **c= eaten_memory, *m;

	PRINTK(SUSPEND_DEBUG, name_suspend "Eating pages\n");
	prepare_status("Eating memory...");

	si_meminfo(&meminfo);
 	max=j=meminfo.totalram*(100-SUSPEND_LOWMEM)/100;

	while ((j>0) && (m = (void *) get_free_page(GFP_HIGHUSER | __GFP_FAST))) {
		memset(m, 0, PAGE_SIZE);
		eaten_memory = m;
		if (!(i%100)) {
			PRINTK(SUSPEND_DEBUG, ".");
			PRINTK(SUSPEND_VERBOSE, "%d", i);
		}
		*eaten_memory = c;
		c = eaten_memory;
		update_status(i*100/max);
		i++;
		j--;
	}
	PRINTK(SUSPEND_DEBUG, "(%dK)\n", i*4);
	update_status(100);
	return(i);
}

static void free_memory(int nb)
{
	int i = 0;
	void **c = eaten_memory, *f;
	
	PRINTK(SUSPEND_DEBUG, name_suspend "Freeing pages\n");
	prepare_status("Freeing memory...");
	while (c) {
		if (!(i%100))
			PRINTK(SUSPEND_DEBUG, "."); 
		f = c;
		c = *c;
		free_page( (long) f );
		update_status(i*100/nb);
		i++;
	}
	PRINTK(SUSPEND_DEBUG, "(%dK)\n", i*4);
	eaten_memory = NULL;
	update_status(100);
}

/*
 * Try to free as much memory as possible, but do not OOM-kill anyone
 *
 * Notice: all userland should be stopped at this point, or livelock is possible.
 */
static void free_some_memory(void)
{
	int nb;
	
	if (SUSPEND_FREEMEM) {
		PRINTK(SUSPEND_DEBUG, name_suspend "Freeing memory\n");
		while (try_to_free_pages_zone(&contig_page_data.node_zones[ZONE_HIGHMEM], GFP_KSWAPD))
			PRINTK(SUSPEND_DEBUG, ".");
		PRINTK(SUSPEND_DEBUG, "|\n");
	} else {
		PRINTK(SUSPEND_DEBUG, name_suspend "Using memeat\n");
		nb=eat_memory();
		free_memory(nb);
	}
}

/* Make disk drivers accept operations, again */
static void drivers_unsuspend(void)
{
#ifdef CONFIG_BLK_DEV_IDE
	ide_disk_unsuspend(0);
#endif
}

/* Called from process context */
static int drivers_suspend(void)
{
#ifdef CONFIG_BLK_DEV_MD
	md_notify_reboot(NULL, SYS_HALT, NULL);
#endif
#ifdef CONFIG_BLK_DEV_IDE
	ide_disk_suspend();
#endif
	if (!pm_suspend_state) {
		if (pm_send_all(PM_SUSPEND,(void *)3)) {
			printk(name_suspend "Problem while sending suspend event\n");
			return(1);
		}
		pm_suspend_state=1;
	} else
		PRINTK(SUSPEND_VERBOSE, name_suspend "PM suspend state already raised\n");
	  
	return(0);
}

#define RESUME_PHASE1 1 /* Called from interrupts disabled */
#define RESUME_PHASE2 2 /* Called with interrupts enabled */
#define RESUME_ALL_PHASES (RESUME_PHASE1 | RESUME_PHASE2)
static void drivers_resume(int flags)
{
  	if(flags & RESUME_PHASE2) {
#ifdef CONFIG_BLK_DEV_HD
		do_reset_hd();			/* Kill all controller state */
#endif
	}
  	if (flags & RESUME_PHASE1) {
#ifdef CONFIG_BLK_DEV_IDE
		ide_disk_unsuspend(1);		
#endif
#ifdef CONFIG_BLK_DEV_MD
		md_autostart_arrays();
#endif
	}
  	if (flags & RESUME_PHASE2) {
		if (pm_suspend_state) {
			if (pm_send_all(PM_RESUME,(void *)0))
				printk(name_resume "Problem while sending resume event\n");
			pm_suspend_state=0;
		} else
			PRINTK(SUSPEND_DEBUG, name_resume "PM suspend state wasn't raised\n");

#ifdef SUSPEND_CONSOLE
		update_screen(fg_console);	/* Hmm, is this the problem? */
#endif
	}
}

static int save_suspend_image(void)
{
	struct sysinfo i;
	unsigned int nr_needed_pages = 0;

	pagedir_nosave = NULL;
	PRINTK(SUSPEND_VERBOSE, name_suspend "/critical section: Counting pages to copy");
	pageset1_size = count_and_copy_data_pages(NULL);
	nr_needed_pages = pageset1_size + PAGES_FOR_IO;
	
	if (SUSPEND_ABORTING)
		return -1;

	PRINTK(SUSPEND_DEBUG, name_suspend " (pages needed: %d+%d=%d free: %d)\n",pageset1_size,PAGES_FOR_IO,nr_needed_pages,nr_free_pages());
	if (nr_free_pages() < nr_needed_pages) {
		printk(KERN_CRIT name_suspend "Couldn't get enough free pages, on %d pages short\n",
			 nr_needed_pages-nr_free_pages());
		spin_unlock_irq(&suspend_pagedir_lock);
		return 1;
	}
	si_swapinfo(&i);	/* FIXME: si_swapinfo(&i) returns all swap devices information.
				   We should only consider resume_device. */
	if (i.freeswap < nr_needed_pages)  {
		printk(KERN_CRIT name_suspend "There's not enough swap space available, free: %ld need: %d lacks: %ld\n",
		       i.freeswap,
		       nr_needed_pages,
		       nr_needed_pages-i.freeswap);
		spin_unlock_irq(&suspend_pagedir_lock);
		return 1;
	}

#define abort_and_return(f, a...) do	{ \
		abort_suspend(f, ## a); \
		free_suspend_pagedir(pagedir_save); \
		spin_unlock_irq(&suspend_pagedir_lock); \
		return 1; \
	} while(0)
	
	PRINTK(SUSPEND_VERBOSE, "Alloc pagedir\n"); 
	pagedir_nosave = create_suspend_pagedir(pageset1_size);
	pagedir_save = pagedir_nosave;
	if (!pagedir_nosave) {
		/* Shouldn't happen */
		printk(KERN_CRIT name_suspend "Couldn't allocate enough pages\n");
		abort_and_return("Really should not happen");
	}
	pageset1_size_check = pageset1_size;
	pagedir_order_check = pagedir_order;

	if (pageset1_size != count_and_copy_data_pages(pagedir_nosave))	/* copy */
		abort_and_return("Number of pages copied doesn't match previous count!\n");


	if (SUSPEND_PAUSE_BETWEEN_STEPS)
		WAIT_FOR_SHIFT;

	/*
	 * End of critical section. From now on, we can write to memory,
	 * but we should not touch disk. This specially means we must _not_
	 * touch swap space! Except we must write out our image of course.
	 *
	 * Following line enforces not writing to disk until we choose.
	 */
	drivers_unsuspend();
	spin_unlock_irq(&suspend_pagedir_lock);
	PRINTK(SUSPEND_VERBOSE, name_suspend "critical section/: done (%d pages copied)\n", pageset1_size);

	lock_swapdevices();
	write_suspend_image();

	if (SUSPEND_PAUSE_BETWEEN_STEPS)
		WAIT_FOR_SHIFT;

	lock_swapdevices();	/* This will unlock ignored swap devices since writing is finished */
	if (SUSPEND_ABORTING)
		return -1;
	return 0;
}

extern void (*pm_power_off)(void);
extern void swsusp_power_off(void);
void suspend_power_down(void)
{
	C_A_D = 0;
	PRINTK(SUSPEND_DEBUG, name_suspend "Trying to power down.\n");
	mdelay(1000);		/* FIXME: we need to flush hw disk cache
				   in a more certain way */
#ifdef CONFIG_VT
	if (SUSPEND_REBOOT)
		machine_restart(NULL);
	else
#endif
	{
		if(!pm_power_off) {
			pm_power_off=swsusp_power_off;
			PRINTK(SUSPEND_DEBUG, name_suspend "Trying to use an apm bios call (you should enable apm or acpi)\n"); 
		}
		machine_power_off();
	}

	printk(KERN_EMERG name_suspend "Probably not capable for powerdown.\n");
	machine_halt();
	printk(KERN_EMERG name_suspend "System is now halted.\n");
	while (1)
		cpu_relax();
	/* NOTREACHED */
}

/*
 * Magic happens here
 */

static void do_magic_resume_1(void)
{
	barrier();
	mb();
	spin_lock_irq(&suspend_pagedir_lock);	/* Done to disable interrupts */ 

	PRINTK(SUSPEND_DEBUG, name_resume "Waiting for DMAs to settle down...\n");
	mdelay(1000);	/* We do not want some readahead with DMA to corrupt our memory, right?
			   Do it with disabled interrupts for best effect. That way, if some
			   driver scheduled DMA, we have good chance for DMA to finish ;-). */
}

static void do_magic_resume_2(void)
{
	now_resuming = 1;

	if (pageset1_size_check != pageset1_size) {
		abort_suspend("pageset1_size_check (%d) != pageset1_size (%d)", pageset1_size_check, pageset1_size);
		return;
	}
	if (pagedir_order_check != pagedir_order) {
		abort_suspend("pagedir_order_check (%d) != pagedir_order (%d)", pagedir_order_check, pagedir_order);
		return;
	}
	prepare_status("Cleaning up...");
	update_status(100);
	PRINTK(SUSPEND_DEBUG, name_resume "Freeing prev allocated pagedir\n");
	free_suspend_pagedir(pagedir_save);
	__flush_tlb_global();		/* Even mappings of "global" things (vmalloc) need to be fixed */
	drivers_resume(RESUME_ALL_PHASES);
	spin_unlock_irq(&suspend_pagedir_lock);

	PRINTK(SUSPEND_DEBUG, name_resume "Fixing swap signatures... ");
	mark_swapfiles(((swp_entry_t) {0}), MARK_SWAP_RESUME);
	PRINTK(SUSPEND_DEBUG, "ok\n");

#ifdef SUSPEND_CONSOLE
	update_screen(fg_console);	/* Hmm, is this the problem? */
#endif
}

static void do_magic_suspend_1(void)
{
	mb();
	barrier();
	spin_lock_irq(&suspend_pagedir_lock);
}

static void do_magic_suspend_2(void)
{
#ifdef DEBUG_DEFAULT
	currentstage = STAGE_WRITE_PAGESETS;
#endif
	read_swapfiles();
	if (!save_suspend_image())
		suspend_power_down ();
#ifdef DEBUG_DEFAULT
	currentstage = 0;
#endif
	printk(KERN_EMERG name_suspend "Suspend failed, trying to recover...\n");
	MDELAY(1000); /* So user can wait and report us messages if armageddon comes :-) */

	barrier();
	mb();
	drivers_resume(RESUME_PHASE2);
	spin_lock_irq(&suspend_pagedir_lock);	/* Done to disable interrupts */ 
	mdelay(1000);

	free_pages((unsigned long) pagedir_nosave, pagedir_order);
	drivers_resume(RESUME_PHASE1);
	spin_unlock_irq(&suspend_pagedir_lock);
	mark_swapfiles(((swp_entry_t) {0}), MARK_SWAP_RECOVER);
	PRINTK(SUSPEND_DEBUG, name_suspend "Leaving do_magic_suspend_2...\n");	
}

#define SUSPEND_C
#include <asm/suspend.h>

/*
 * We try to swap out as much as we can then make a copy of the
 * occupied pages in memory so we can make a copy of kernel state
 * atomically, the I/O needed by saving won't bother us anymore. 
 */
static void do_software_suspend(void)
{
	now_resuming = 0;
	if (prepare_suspend_console())
		printk(name_suspend "Can't allocate a console... proceeding\n");
#ifdef DEBUG_DEFAULT
	currentstage = STAGE_FREEZER;
#endif
	if (!prepare_suspend_processes()) {
#ifdef DEBUG_DEFAULT
		currentstage = STAGE_EAT_MEMORY;
#endif
		free_some_memory();

#ifdef DEBUG_DEFAULT
		currentstage = 0;
#endif
		/* No need to invalidate any vfsmnt list -- they will be valid after resume, anyway.
		 *
		 * We sync here -- so you have consistent filesystem state when things go wrong.
		 * -- so that noone writes to disk after we do atomic copy of data.
		 */
		PRINTK(SUSPEND_DEBUG, name_suspend "Syncing disks before copy\n" );
		do_suspend_sync();
		if (drivers_suspend()==0)
			do_suspend_lowlevel(0);			/* This function returns after machine woken up from resume */
		PRINTK(SUSPEND_DEBUG, name_resume "Restarting processes...\n");
		thaw_processes();
	}
	
	MDELAY(1000);
	restore_console ();
}

static void software_suspend(void)
{
	PRINTK(SUSPEND_DEBUG, name_swsusp "Entering software_suspend\n");
	if (!software_suspend_enabled) {
		printk(name_swsusp "software suspend is disabled\n");
		return;
	}
	if (!(cpu_has_pse||cpu_has_pse36)) {
		printk(name_swsusp "pse or pse36 is required, disabling software suspend");
		return;
	}
	if (in_interrupt())
		BUG();
	software_suspend_enabled = 0;
	do_software_suspend();
	software_suspend_enabled = 1;
}

/*
 * This is main interface to the outside world. It needs to be
 * called from process context. It notifies kswsuspd thread
 * through SUSPEND_PENDING and wait for resume.
 */
void software_suspend_pending(void)
{
	swsusp_state[0] = 1;
	while(SUSPEND_PENDING) {
	  	schedule();
		if (current->flags & PF_FREEZE)
			refrigerator(PF_IOTHREAD);
		set_current_state(TASK_INTERRUPTIBLE); /* wait for resume */
	}
}

/* More restore stuff */

/* FIXME: Why not memcpy(to, from, 1<<pagedir_order*PAGE_SIZE)? */
static void copy_pagedir(suspend_pagedir_t *to, suspend_pagedir_t *from)
{
	int i;
	char *topointer=(char *)to, *frompointer=(char *)from;

	for(i=0; i < 1 << pagedir_order; i++) {
		copy_page(topointer, frompointer);
		topointer += PAGE_SIZE;
		frompointer += PAGE_SIZE;
	}
}

#define does_collide(addr) does_collide_order(pagedir_nosave, addr, 0)

/*
 * Returns true if given address/order collides with any address1 
 */
static int does_collide_order(suspend_pagedir_t *pagedir, unsigned long addr,
		int order)
{
	int i;
	unsigned long addre = addr + (PAGE_SIZE<<order);
	
	for(i=0; i < pageset1_size; i++)
		if ((pagedir+i)->address1 >= addr &&
			(pagedir+i)->address1 < addre)
			return 1;

	return 0;
}

/*
 * We check here that pagedir & pages it points to won't collide with pages
 * where we're going to restore from the loaded pages later
 */

static int check_pagedir(void)
{
	int i;

	for(i=0; i < pageset1_size; i++) {
		unsigned long addr;

		do {
			addr = get_free_page(GFP_ATOMIC);
			if (!addr)
				return -ENOMEM;
		} while (does_collide(addr));

		(pagedir_nosave+i)->address3 = addr;
	}
	return 0;
}

static int relocate_pagedir(void)
{
	/*
	 * We have to avoid recursion (not to overflow kernel stack),
	 * and that's why code looks pretty cryptic 
	 */
	suspend_pagedir_t *new_pagedir, *old_pagedir = pagedir_nosave;
	void **eaten_memory = NULL;
	void **c = eaten_memory, *m, *f;

	PRINTK(SUSPEND_DEBUG, name_resume "Relocating pagedir");

	if (!does_collide_order(old_pagedir, (unsigned long)old_pagedir, pagedir_order)) {
		PRINTK(SUSPEND_DEBUG, " isn't necessary\n");
		return 0;
	}
	PRINTK(SUSPEND_DEBUG, "\nSeeking new pagedir location:    ");

	while ((m = (void *) __get_free_pages(GFP_ATOMIC, pagedir_order))) {
		memset(m, 0, PAGE_SIZE);
		if (!does_collide_order(old_pagedir, (unsigned long)m, pagedir_order))
			break;
		eaten_memory = m;
		PRINTK(SUSPEND_DEBUG, "."); 
		*eaten_memory = c;
		c = eaten_memory;
	}
	PRINTK(SUSPEND_DEBUG, "\n"); 

	if (!m)
		return -ENOMEM;

	pagedir_nosave = new_pagedir = m;
	copy_pagedir(new_pagedir, old_pagedir);

	PRINTK(SUSPEND_DEBUG, "Freeing rejected memory locations");
	c = eaten_memory;
	while(c) {
		PRINTK(SUSPEND_DEBUG, ":"); 
		f = *c;
		c = *c;
		if (f)
			free_pages((unsigned long)f, pagedir_order);
	}
	PRINTK(SUSPEND_DEBUG, "|\n");
	return 0;
}

/*
 * Sanity check if this image makes sense with this kernel/swap context
 * I really don't think that it's foolproof but more than nothing..
 */

static int sanity_check_failed(char *reason)
{
	printk(KERN_ERR name_resume "%s\n",reason);
	printk(KERN_ERR "Press SHIFT to reboot or CONTROL to continue booting with this kernel\n");
	while (!(shift_state & ((1 << KG_SHIFT) | (1 << KG_CTRL)))) 
		schedule(); 
	if (shift_state & (1 << KG_SHIFT))
		machine_restart(NULL);
	return -EPERM;
}

static int sanity_check(struct suspend_header *sh)
{
	if (sh->version_code != LINUX_VERSION_CODE)
		return sanity_check_failed("Incorrect kernel version");
	if (sh->num_physpages != num_physpages)
		return sanity_check_failed("Incorrect memory size");
	if (strncmp(sh->machine, system_utsname.machine, 65))
		return sanity_check_failed("Incorrect machine type");
	if (strncmp(sh->version, system_utsname.version, 65))
		return sanity_check_failed("Incorrect version");
	if (sh->num_cpus != smp_num_cpus)
		return sanity_check_failed("Incorrect number of cpus");
	if (sh->page_size != PAGE_SIZE)
		return sanity_check_failed("Incorrect PAGE_SIZE");
	return 0;
}

static int bdev_read_page(kdev_t dev, long pos, void *buf)
{
	struct buffer_head *bh;
	if (pos%PAGE_SIZE) {
		abort_suspend("pos > pagesize!\n");
		return -EIO;
	}
	BREAD_BUFFER_HEAD(pos);
	memcpy(buf, bh->b_data, PAGE_SIZE);
	if (!buffer_uptodate(bh)) {
		abort_suspend("buffer_uptodate false in bdev_read_page!\n");
		brelse(bh);
		BFREE;
		return -1;
	}
	brelse(bh);
	BFREE;
	return 0;
} 

static int swsusp_mainloop(void *unused)
{
  	printk(name_swsusp "kswsuspd starting\n"); /* This will print the current version on boot */
	daemonize();

	strcpy(current->comm, "kswsuspd");
	sigfillset(&current->blocked);
	current->flags |= PF_IOTHREAD;

	for(;;) {
		set_current_state(TASK_INTERRUPTIBLE);
		for(;!SUSPEND_PENDING;) {	  
			schedule_timeout(SWSUSP_CHECK_TIMEOUT);
			set_current_state(TASK_INTERRUPTIBLE);
		}
		software_suspend();
		swsusp_state[0] = 0;
	}
	return(0);
}

static int noresume_fix_signature(union p_diskpage cur)
{
	struct buffer_head *bh;
				/* We don't do a sanity check here: we want to restore the swap
				   whatever version of kernel made the suspend image */
	printk(name_resume "%s: Fixing swap signatures...\n", resume_file);
				/* We need to write swap, but swap is *not* enabled so
				   we must write the device directly */
	PRINTK(SUSPEND_VERBOSE,"Swap signature will be set to %10s\n",cur.pointer->swh.magic.magic);
	BREAD_BUFFER_HEAD(0);
	if (is_read_only(bh->b_dev)) {
		printk(KERN_ERR name_resume "Can't write to read-only device %s\n",
		       kdevname(bh->b_dev));
		BFREE;
		return -EIO;
	}
	
	memcpy(bh->b_data, cur.ptr, PAGE_SIZE);
	generic_make_request(WRITE, bh);
	wait_on_buffer(bh);
	if (buffer_uptodate(bh)) {
		brelse(bh);
		BFREE;	
		free_suspend_cache_page();
		/* As with fix_signature, try to read to ensure its written. */
		BREAD_BUFFER_HEAD(0);
		brelse(bh);
		BFREE;
		return 0;
	}
	printk(name_resume "Warning %s: Fixing swap signatures unsuccessful...\n", resume_file);
	bforget(bh);
	BFREE;
	return -EINVAL;		/* non fatal error */
}

static int __read_suspend_image(kdev_t bdev, union p_diskpage cur, int noresume)
{				/* returned values:
				   -EINVAL in case of swapspace or if noresume is set and swap signature
				   wasn't correctly fixed (non fatal error),
				   0 if suspended image was correctly read or if noresume is set
				   and swap signature was correctly fixed,
				   other non zero values are errors. */
	swp_entry_t next;
	int i, nr_pgdir_pages, len, *ptr;

#define PREPARENEXT do { \
		next = cur.pointer->link.next; \
		next.val = SWP_OFFSET(next) * PAGE_SIZE; \
        } while(0)
	if (bdev_read_page(bdev, 0, cur.ptr)) return -EIO;

	if ((!memcmp("SWAP-SPACE",cur.pointer->swh.magic.magic,10)) ||
	    (!memcmp("SWAPSPACE2",cur.pointer->swh.magic.magic,10))) {
		printk(KERN_ERR name_resume "This is normal swap space\n" );
		return -EINVAL;	/* non fatal error */
	}
	PREPARENEXT; /* We have to read next position before we overwrite it */

	if (!memcmp("SUSP1R",cur.pointer->swh.magic.magic,6))
		memcpy(cur.pointer->swh.magic.magic,"SWAP-SPACE",10);
	else if (!memcmp("SUSP2R",cur.pointer->swh.magic.magic,6))
		memcpy(cur.pointer->swh.magic.magic,"SWAPSPACE2",10);
	else {
		printk("%sUnable to find suspended-data signature (%.10s - misspelled?\n", 
			name_resume, cur.pointer->swh.magic.magic);
		return -EINVAL;
		/* We want to abort_suspend even with noresume -- we certainly don't want to add
		   our signature into your ext2 filesystem ;-) */
	}
	if (noresume)
		return(noresume_fix_signature(cur));
	
	PRINTK(SUSPEND_VERBOSE, name_resume "Signature found, resuming\n");
	MDELAY(1000);

	if (bdev_read_page(bdev, next.val, cur.ptr)) return -EIO;	
	if (sanity_check(&(cur.pointer->sh))) /* Is this the same machine? */
		return -EPERM;
#ifdef SOFTWARE_SUSPEND_MTRR
	ptr = ((int *)((char *) cur.ptr +sizeof(struct suspend_header)));
	len = *ptr;
	if(len)
		mtrr_resume(ptr);
#endif
	PREPARENEXT;

	pagedir_save = cur.pointer->sh.suspend_pagedir;
	pageset1_size = cur.pointer->sh.pageset1_size;
	nr_pgdir_pages = SUSPEND_PD_PAGES(pageset1_size);
	pagedir_order = get_bitmask_order(nr_pgdir_pages);

        swsusp_state[0] = cur.pointer->sh.param0;
        swsusp_state[1] = cur.pointer->sh.param1;
        swsusp_state[2] = cur.pointer->sh.param2;
        swsusp_state[3] = cur.pointer->sh.param3;
	swsusp_state[4] = cur.pointer->sh.param4;

	now_resuming = 1;
	if (prepare_suspend_console())
		printk(name_resume "Can't allocate a console... proceeding\n");

	pagedir_nosave = (suspend_pagedir_t *)__get_free_pages(GFP_ATOMIC, pagedir_order);
	if (!pagedir_nosave)
		return -ENOMEM;

	PRINTK(SUSPEND_DEBUG, name_resume "Reading pagedir of %d pages, %lx", pageset1_size, next.val);

	/* We get pages in reverse order of saving! */
	for (cur.pointer=(union diskpage *)pagedir_nosave + (i=nr_pgdir_pages-1);
	     i>=0;
	     i--,
	     cur.pointer--) {
#ifdef DEBUG_DEFAULT
		if ((i < PRINTTHRESH) || ((i+PRINTTHRESH) > nr_pgdir_pages))
			PRINTK(SUSPEND_VERBOSE, "[sw]%lx -> [pd%d]%p.\n", next.val, i, cur.pointer);
#endif
		if (!next.val) {
			abort_suspend("next.val is NULL in __read_suspend_image!\n");
			return -1;
		}
		if (bdev_read_page(bdev, next.val, cur.ptr)) return -EIO;	
		PREPARENEXT;
	}
	if (next.val) {
		abort_suspend("next.val not NULL in __read_suspend_image!\n");
		return -1;
	}

	if (SUSPEND_PAUSE_BETWEEN_STEPS)
		WAIT_FOR_SHIFT;


	if (relocate_pagedir())
		return -ENOMEM;
	if (check_pagedir())
		return -ENOMEM;

	PRINTK(SUSPEND_DEBUG, name_resume "reading image data (%d pages)\n", pageset1_size);
	prepare_status("Reading suspend image...");
	for(i=0; i < pageset1_size; i++) {
		swp_entry_t swap_address1 = (pagedir_nosave+i)->swap_address1;
		if (!(i%100))
			PRINTK(SUSPEND_DEBUG, ".");
#ifdef DEBUG_DEFAULT
		if ((i+PRINTTHRESH) > pageset1_size)
			PRINTK(SUSPEND_VERBOSE, "!%d! [sw]%lx -> [3]%lx (->[1]%lx).\n", i, next.val, (pagedir_nosave+i)->address3, (pagedir_nosave+i)->address1);
#endif
		update_status((int) (i * 100 / pageset1_size));
		next.val = SWP_OFFSET (swap_address1) * PAGE_SIZE;
		/* You do not need to check for overlaps...
		   ... check_pagedir already did this work */
		if (bdev_read_page(bdev, next.val, (char *)((pagedir_nosave+i)->address3))) return -EIO;	
	}
	PRINTK(SUSPEND_DEBUG, "|\n");

	if (SUSPEND_PAUSE_BETWEEN_STEPS)
		WAIT_FOR_SHIFT;

	update_status(100);
	return 0;
}

static int read_suspend_image(char * specialfile, int noresume)
{
	union p_diskpage cur;
	unsigned long scratch_page = 0;
	int error, blksize = 0;

	resume_device = name_to_kdev_t(specialfile);
	scratch_page = get_free_page(GFP_ATOMIC);
	if (scratch_page) {
		cur.address = scratch_page;
		PRINTK(SUSPEND_DEBUG, name_resume "Resuming from device %x\n", resume_device);

		if (!blksize_size[MAJOR(resume_device)]) {
			PRINTK(SUSPEND_DEBUG, name_resume "Blocksize not known?\n");
		} else blksize = blksize_size[MAJOR(resume_device)][MINOR(resume_device)];
		if (!blksize) {
			PRINTK(SUSPEND_DEBUG, name_resume "Blocksize not set?\n");
			blksize = PAGE_SIZE;
		}
		set_blocksize(resume_device, PAGE_SIZE);
		error = __read_suspend_image(resume_device, cur, noresume);
		free_page(scratch_page);
	} else error = -ENOMEM;

	switch (error) {
		case 0:
		case -EINVAL:	/* non fatal error */
			set_blocksize(resume_device, blksize);
			MDELAY(1000);
			return(error);
			break;
		case -EIO:
			printk(KERN_CRIT name_resume "I/O error\n");
			break;
		case -ENOENT:
			printk(KERN_CRIT name_resume "%s: No such file or directory\n", specialfile);
			break;
		case -EPERM:
			printk(KERN_CRIT name_resume "Sanity check error\n");
			break;
		default:
			printk(KERN_CRIT name_resume "Error %d resuming\n", error);
			break;
	}
	abort_suspend("Error %d in read_suspend_image",error);
	return(error);
}
/*
 * Called from init kernel_thread.
 * We check if we have an image and if so we try to resume
 */

void software_resume(void)
{
#ifdef CONFIG_SMP
	printk(name_swsusp "malfunctioning SMP support. Disabled :(\n");
#else
	/* We enable the possibility of machine suspend */
	software_suspend_enabled = 1;
#endif
	copybuff = get_free_page(GFP_ATOMIC);

	if (!resume_status)
		return;

	if (resume_status == NORESUME) {
		PRINTK(SUSPEND_DEBUG, name_swsusp "resuming disabled\n");
		if (resume_file[0])
			read_suspend_image(resume_file,1); /* non fatal error ignored */
		kernel_thread(swsusp_mainloop, NULL, CLONE_FS | CLONE_FILES | CLONE_SIGHAND | SIGCHLD);
		return;
	}
	MDELAY(1000);

	orig_loglevel = console_loglevel;
	console_loglevel = new_loglevel;

	if (!resume_file[0] && resume_status == RESUME_SPECIFIED) {
		printk(name_swsusp "suspension device unspecified\n");
		software_suspend_enabled = 0;
		return;
	}

	PRINTK(SUSPEND_DEBUG, name_swsusp "resuming from %s\n", resume_file);
	if (read_suspend_image(resume_file, 0)) { /* non fatal error (normal swap space) */
		kernel_thread(swsusp_mainloop, NULL, CLONE_FS | CLONE_FILES | CLONE_SIGHAND | SIGCHLD);
		console_loglevel = orig_loglevel;
		return;
	}		

	prepare_status("Copying pages back (no status - sensitive!)...");

	do_suspend_lowlevel(1);
	BUG();
}

static int __init resume_setup(char *str)
{
	if (resume_status)
		return 1;
	if( (str == NULL) || (strncmp(str, "/dev/h", 6)) ) {
		printk(name_swsusp "software suspend is currently only compatible with IDE /dev/h?? swap partitions: disabled\n");
		resume_status = 0;
		software_suspend_enabled = 0;
		return 1;
	}

	strncpy( resume_file, str, 255 );
	resume_status = RESUME_SPECIFIED;

	return 0;
}

static int __init swsusp_dbg_setup(char *str)
{
	if(str)
		swsusp_state[2]=simple_strtol(str,NULL,0);
	printk(name_swsusp "debug parameter set : %x\n",swsusp_state[2]);
	PRINTK(SUSPEND_DEBUG,"debugging messages enabled\n");
	PRINTK(SUSPEND_PROGRESS,"displaying progress bar enabled\n");
	PRINTK(SUSPEND_VERBOSE,"verbose messages enabled\n");
	PRINTK(SUSPEND_SLOW,"slow down delays enabled\n");
	PRINTK(SUSPEND_DEBUG_MAP,"debugging pagemap messages enabled\n");
	return 0;
}

static int __init software_noresume(char *str)
{
	resume_status = NORESUME;
	if (!resume_status) {
		printk(name_swsusp "noresume option lacks a resume= option\n");
		return 1;
	}
	return 0;
}

__setup("resume=", resume_setup);
__setup("swsusp_dbg=", swsusp_dbg_setup);
__setup("noresume", software_noresume);

EXPORT_SYMBOL(software_suspend_pending);
EXPORT_SYMBOL(swsusp_state);
EXPORT_SYMBOL(software_suspend_enabled);
EXPORT_SYMBOL(refrigerator);
