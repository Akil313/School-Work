/*
 *  linux/arch/i386/mm/fault.c
 *
 *  Copyright (C) 1995  Linus Torvalds
 */

#include <linux/config.h>
#include <linux/signal.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <linux/types.h>
#include <linux/ptrace.h>
#include <linux/mman.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/smp_lock.h>
#include <linux/interrupt.h>
#include <linux/init.h>
#include <linux/tty.h>
#include <linux/vt_kern.h>		/* For unblank_screen() */
#include <linux/unistd.h>
#include <linux/compiler.h>

#include <asm/system.h>
#include <asm/uaccess.h>
#include <asm/pgalloc.h>
#include <asm/hardirq.h>

extern void die(const char *,struct pt_regs *,long);

/*
 * Ugly, ugly, but the goto's result in better assembly..
 */
int __verify_write(const void * addr, unsigned long size)
{
	struct vm_area_struct * vma, * prev_vma;
	unsigned long start = (unsigned long) addr;

	if (!size)
		return 1;

	vma = find_vma(current->mm, start);
	if (!vma)
		goto bad_area;
	if (vma->vm_start > start)
		goto check_stack;

good_area:
	if (!(vma->vm_flags & VM_WRITE))
		goto bad_area;
	size--;
	size += start & ~PAGE_MASK;
	size >>= PAGE_SHIFT;
	start &= PAGE_MASK;

	for (;;) {
	survive:
		{
			int fault = handle_mm_fault(current->mm, vma, start, 1);
			if (!fault)
				goto bad_area;
			if (fault < 0)
				goto out_of_memory;
		}
		if (!size)
			break;
		size--;
		start += PAGE_SIZE;
		if (start < vma->vm_end)
			continue;
		vma = vma->vm_next;
		if (!vma || vma->vm_start != start)
			goto bad_area;
		if (!(vma->vm_flags & VM_WRITE))
			goto bad_area;;
	}
	return 1;

check_stack:
	if (!(vma->vm_flags & VM_GROWSDOWN))
		goto bad_area;
	find_vma_prev(current->mm, start, &prev_vma);
	if (expand_stack(vma, start, prev_vma) == 0)
		goto good_area;

bad_area:
	return 0;

out_of_memory:
	if (current->pid == 1) {
		yield();
		goto survive;
	}
	goto bad_area;
}

extern spinlock_t timerlist_lock;

/*
 * Unlock any spinlocks which will prevent us from getting the
 * message out (timerlist_lock is acquired through the
 * console unblank code)
 */
void bust_spinlocks(int yes)
{
	spin_lock_init(&timerlist_lock);
	if (yes) {
		oops_in_progress = 1;
#ifdef CONFIG_SMP
		global_irq_lock = 0;	/* Many serial drivers do __global_cli() */
#endif
	} else {
		int loglevel_save = console_loglevel;
#ifdef CONFIG_VT
		unblank_screen();
#endif
		oops_in_progress = 0;
		/*
		 * OK, the message is on the console.  Now we call printk()
		 * without oops_in_progress set so that printk will give klogd
		 * a poke.  Hold onto your hats...
		 */
		console_loglevel = 15;		/* NMI oopser may have shut the console up */
		printk(" ");
		console_loglevel = loglevel_save;
	}
}

asmlinkage void do_invalid_op(struct pt_regs *, unsigned long);
extern unsigned long idt;

#ifdef CONFIG_GRKERNSEC
static void pax_report_fault(struct pt_regs *regs);
static int pax_handle_read_fault(struct pt_regs *regs);
#endif
/*
 * This routine handles page faults.  It determines the address,
 * and the problem, and then passes it off to one of the appropriate
 * routines.
 *
 * error_code:
 *	bit 0 == 0 means no page found, 1 means protection fault
 *	bit 1 == 0 means read, 1 means write
 *	bit 2 == 0 means kernel, 1 means user-mode
 */
#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
static int do_page_fault(struct pt_regs *regs, unsigned long error_code, unsigned long address)
#else
asmlinkage void do_page_fault(struct pt_regs *regs, unsigned long error_code)
#endif
{
	struct task_struct *tsk;
	struct mm_struct *mm;
	struct vm_area_struct * vma, * prev_vma;
#ifndef CONFIG_GRKERNSEC_PAX_PAGEEXEC
	unsigned long address;
#endif
	unsigned long page;
	unsigned long fixup;
	int write;
	siginfo_t info;

#ifndef CONFIG_GRKERNSEC_PAX_PAGEEXEC
	/* get the address */
	__asm__("movl %%cr2,%0":"=r" (address));

	/* It's safe to allow irq's after cr2 has been saved */
	if (likely(regs->eflags & X86_EFLAGS_IF))
		local_irq_enable();

	tsk = current;
#endif

	/*
	 * We fault-in kernel-space virtual memory on-demand. The
	 * 'reference' page table is init_mm.pgd.
	 *
	 * NOTE! We MUST NOT take any locks for this case. We may
	 * be in an interrupt or a critical region, and should
	 * only copy the information from the master page table,
	 * nothing more.
	 *
	 * This verifies that the fault happens in kernel space
	 * (error_code & 4) == 0, and that the fault was not a
	 * protection error (error_code & 1) == 0.
	 */
	if (address >= TASK_SIZE && !(error_code & 5))
		goto vmalloc_fault;

	mm = tsk->mm;
	info.si_code = SEGV_MAPERR;

	/*
	 * If we're in an interrupt or have no user
	 * context, we must not take the fault..
	 */
	if (in_interrupt() || !mm)
		goto no_context;

	down_read(&mm->mmap_sem);

	vma = find_vma(mm, address);
	if (!vma)
		goto bad_area;
	if (vma->vm_start <= address)
		goto good_area;
	if (!(vma->vm_flags & VM_GROWSDOWN))
		goto bad_area;
	if (error_code & 4) {
		/*
		 * accessing the stack below %esp is always a bug.
		 * The "+ 32" is there due to some instructions (like
		 * pusha) doing post-decrement on the stack and that
		 * doesn't show up until later..
		 */
		if (address + 32 < regs->esp)
			goto bad_area;
	}
	find_vma_prev(mm, address, &prev_vma);
	if (expand_stack(vma, address, prev_vma))
		goto bad_area;
/*
 * Ok, we have a good vm_area for this memory access, so
 * we can handle it..
 */
good_area:
	info.si_code = SEGV_ACCERR;
	write = 0;
	switch (error_code & 3) {
		default:	/* 3: write, present */
#ifdef TEST_VERIFY_AREA
			if (regs->cs == KERNEL_CS)
				printk("WP fault at %08lx\n", regs->eip);
#endif
			/* fall through */
		case 2:		/* write, not present */
			if (!(vma->vm_flags & VM_WRITE))
				goto bad_area;
			write++;
			break;
		case 1:		/* read, present */
			goto bad_area;
		case 0:		/* read, not present */
			if (!(vma->vm_flags & (VM_READ | VM_EXEC)))
				goto bad_area;
	}

 survive:
	/*
	 * If for any reason at all we couldn't handle the fault,
	 * make sure we exit gracefully rather than endlessly redo
	 * the fault.
	 */
	switch (handle_mm_fault(mm, vma, address, write)) {
	case 1:
		tsk->min_flt++;
		break;
	case 2:
		tsk->maj_flt++;
		break;
	case 0:
		goto do_sigbus;
	default:
		goto out_of_memory;
	}

	/*
	 * Did it hit the DOS screen memory VA from vm86 mode?
	 */
	if (regs->eflags & VM_MASK) {
		unsigned long bit = (address - 0xA0000) >> PAGE_SHIFT;
		if (bit < 32)
			tsk->thread.screen_bitmap |= 1 << bit;
	}
	up_read(&mm->mmap_sem);
#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
	return 0;
#else
	return;
#endif

/*
 * Something tried to access memory that isn't in our memory map..
 * Fix it, but check if it's kernel or user first..
 */
bad_area:
	up_read(&mm->mmap_sem);

	/* User mode accesses just cause a SIGSEGV */
	if (error_code & 4) {
#ifdef CONFIG_GRKERNSEC_PAX_SEGMEXEC
		if (current->flags & PF_PAX_SEGMEXEC) {

#if defined(CONFIG_GRKERNSEC_PAX_EMUTRAMP) || defined(CONFIG_GRKERNSEC_PAX_RANDEXEC)
		if ((error_code == 4) && (regs->eip + TASK_SIZE/2 == address)) {
			switch (pax_handle_read_fault(regs)) {

#ifdef CONFIG_GRKERNSEC_PAX_RANDEXEC
			case 5:
				return 0;
#endif

#ifdef CONFIG_GRKERNSEC_PAX_EMUTRAMP
			case 4:
				return 0;
			case 3:
			case 2:
				return 1;
#endif

			case 1:
			default:
			}
		}
#endif

			if (address >= TASK_SIZE/2) {
				pax_report_fault(regs);
				do_exit(SIGKILL);
			}
		}
#endif

		tsk->thread.cr2 = address;
		tsk->thread.error_code = error_code;
		tsk->thread.trap_no = 14;
		info.si_signo = SIGSEGV;
		info.si_errno = 0;
		/* info.si_code has been set above */
		info.si_addr = (void *)address;
		force_sig_info(SIGSEGV, &info, tsk);
#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
		return 0;
#else
		return;
#endif
	}

	/*
	 * Pentium F0 0F C7 C8 bug workaround.
	 */
	if (boot_cpu_data.f00f_bug) {
		unsigned long nr;
		
		nr = (address - idt) >> 3;

		if (nr == 6) {
			do_invalid_op(regs, 0);
#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
			return 0;
#else
			return;
#endif
		}
	}

no_context:
	/* Are we prepared to handle this kernel fault?  */
	if ((fixup = search_exception_table(regs->eip)) != 0) {
		regs->eip = fixup;
#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
		return 0;
#else
		return;
#endif
	}

/*
 * Oops. The kernel tried to access some bad page. We'll have to
 * terminate things with extreme prejudice.
 */

	bust_spinlocks(1);

	if (address < PAGE_SIZE)
		printk(KERN_ALERT "Unable to handle kernel NULL pointer dereference");
	else
		printk(KERN_ALERT "Unable to handle kernel paging request");
	printk(" at virtual address %08lx\n",address);
	printk(" printing eip:\n");
	printk("%08lx\n", regs->eip);
	asm("movl %%cr3,%0":"=r" (page));
	page = ((unsigned long *) __va(page))[address >> 22];
	printk(KERN_ALERT "*pde = %08lx\n", page);
	if (page & 1) {
		page &= PAGE_MASK;
		address &= 0x003ff000;
		page = ((unsigned long *) __va(page))[address >> PAGE_SHIFT];
		printk(KERN_ALERT "*pte = %08lx\n", page);
	}
	die("Oops", regs, error_code);
	bust_spinlocks(0);
	do_exit(SIGKILL);

/*
 * We ran out of memory, or some other thing happened to us that made
 * us unable to handle the page fault gracefully.
 */
out_of_memory:
	if (tsk->pid == 1) {
		yield();
		goto survive;
	}
	up_read(&mm->mmap_sem);
	printk("VM: killing process %s\n", tsk->comm);
	if (error_code & 4)
		do_exit(SIGKILL);
	goto no_context;

do_sigbus:
	up_read(&mm->mmap_sem);

	/*
	 * Send a sigbus, regardless of whether we were in kernel
	 * or user mode.
	 */
	tsk->thread.cr2 = address;
	tsk->thread.error_code = error_code;
	tsk->thread.trap_no = 14;
	info.si_signo = SIGBUS;
	info.si_errno = 0;
	info.si_code = BUS_ADRERR;
	info.si_addr = (void *)address;
	force_sig_info(SIGBUS, &info, tsk);

	/* Kernel mode? Handle exceptions or die */
	if (!(error_code & 4))
		goto no_context;
#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
	return 0;
#else
	return;
#endif

vmalloc_fault:
	{
		/*
		 * Synchronize this task's top level page-table
		 * with the 'reference' page table.
		 *
		 * Do _not_ use "tsk" here. We might be inside
		 * an interrupt in the middle of a task switch..
		 */
		int offset = __pgd_offset(address);
		pgd_t *pgd, *pgd_k;
		pmd_t *pmd, *pmd_k;
		pte_t *pte_k;

		asm("movl %%cr3,%0":"=r" (pgd));
		pgd = offset + (pgd_t *)__va(pgd);
		pgd_k = init_mm.pgd + offset;

		if (!pgd_present(*pgd_k))
			goto no_context;
		set_pgd(pgd, *pgd_k);
		
		pmd = pmd_offset(pgd, address);
		pmd_k = pmd_offset(pgd_k, address);
		if (!pmd_present(*pmd_k))
			goto no_context;
		set_pmd(pmd, *pmd_k);

		pte_k = pte_offset(pmd_k, address);
		if (!pte_present(*pte_k))
			goto no_context;
#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
		return 0;
#else
		return;
#endif
	}
}
#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
/* PaX: called with the page_table_lock spinlock held */
static inline pte_t * pax_get_pte(struct mm_struct *mm, unsigned long address)
{
	pgd_t *pgd;
	pmd_t *pmd;

	pgd = pgd_offset(mm, address);
	if (!pgd || !pgd_present(*pgd))
		return 0;
	pmd = pmd_offset(pgd, address);
	if (!pmd || !pmd_present(*pmd))
		return 0;
	return pte_offset(pmd, address);
}
#endif

/*
 * PaX: decide what to do with offenders (regs->eip = fault address)
 *
 * returns 1 when task should be killed
 *         2 when sigreturn trampoline was detected
 *         3 when rt_sigreturn trampoline was detected
 *         4 when gcc trampoline was detected
 *	   5 when legitimate ET_EXEC was detected
 */
#if defined(CONFIG_GRKERNSEC_PAX_PAGEEXEC) || defined(CONFIG_GRKERNSEC_PAX_SEGMEXEC)
static int pax_handle_read_fault(struct pt_regs *regs)
{
#ifdef CONFIG_GRKERNSEC_PAX_EMUTRAMP
	static const unsigned char trans[8] = {6, 1, 2, 0, 13, 5, 3, 4};
#endif
	int err;
	
#ifdef CONFIG_GRKERNSEC_PAX_RANDEXEC
	if (current->flags & PF_PAX_RANDEXEC) {
		unsigned long esp_4;
		if (regs->eip >= current->mm->start_code &&
		    regs->eip < current->mm->end_code)
		{
			err = get_user(esp_4, (unsigned long*)(regs->esp-4UL));
			if (!err && esp_4 != regs->eip) {
				regs->eip += current->mm->delta_exec;
				return 5;
			}
		}
	}
#endif

#ifdef CONFIG_GRKERNSEC_PAX_EMUTRAMP
	if (!(current->flags & PF_PAX_EMUTRAMP))
		return 1;

	{ /* PaX: sigreturn emulation */
		unsigned char pop, mov;
		unsigned short sys;
		unsigned long nr;

		err = get_user(pop, (unsigned char *)(regs->eip));
		err |= get_user(mov, (unsigned char *)(regs->eip + 1));
		err |= get_user(nr, (unsigned long *)(regs->eip + 2));
		err |= get_user(sys, (unsigned short *)(regs->eip + 6));

		if (!err) {
			if (pop == 0x58 &&
			    mov == 0xb8 &&
			    nr == __NR_sigreturn &&
			    sys == 0x80cd)
			{
				regs->esp += 4;
				regs->eax = nr;
				regs->eip += 8;
				return 2;
			}
		}
	}

	{ /* PaX: rt_sigreturn emulation */
		unsigned char mov;
		unsigned short sys;
		unsigned long nr;

		err = get_user(mov, (unsigned char *)(regs->eip));
		err |= get_user(nr, (unsigned long *)(regs->eip + 1));
		err |= get_user(sys, (unsigned short *)(regs->eip + 5));

		if (!err) {
			if (mov == 0xb8 &&
			    nr == __NR_rt_sigreturn &&
			    sys == 0x80cd)
			{
				regs->eax = nr;
				regs->eip += 7;
				return 3;
			}
		}
	}

	{ /* PaX: gcc trampoline emulation #1 */
		unsigned char mov1, mov2;
		unsigned short jmp;
		unsigned long addr1, addr2, ret;

		err = get_user(mov1, (unsigned char *)(regs->eip));
		err |= get_user(addr1, (unsigned long *)(regs->eip + 1));
		err |= get_user(mov2, (unsigned char *)(regs->eip + 5));
		err |= get_user(addr2, (unsigned long *)(regs->eip + 6));
		err |= get_user(jmp, (unsigned short *)(regs->eip + 10));
		err |= get_user(ret, (unsigned long *)(regs->esp));

		if (!err) {
			unsigned short call;

			err = get_user(call, (unsigned short *)(ret-2));
			if (!err) {
				if ((mov1 & 0xF8) == 0xB8 &&
				    (mov2 & 0xF8) == 0xB8 &&
				    (mov1 & 0x07) != (mov2 & 0x07) &&
				    (jmp & 0xF8FF) == 0xE0FF &&
				    (mov2 & 0x07) == ((jmp>>8) & 0x07) &&
				    (call & 0xF8FF) == 0xD0FF &&
				    (regs->eip == ((unsigned long*)regs)[trans[(call>>8) & 0x07]]))
				{
					((unsigned long *)regs)[trans[mov1 & 0x07]] = addr1;
					((unsigned long *)regs)[trans[mov2 & 0x07]] = addr2;
					regs->eip = addr2;
					return 4;
				}
			}
		}
	}

	{ /* PaX: gcc trampoline emulation #2 */
		unsigned char mov, jmp;
		unsigned long addr1, addr2, ret;

		err = get_user(mov, (unsigned char *)(regs->eip));
		err |= get_user(addr1, (unsigned long *)(regs->eip + 1));
		err |= get_user(jmp, (unsigned char *)(regs->eip + 5));
		err |= get_user(addr2, (unsigned long *)(regs->eip + 6));
		err |= get_user(ret, (unsigned long *)(regs->esp));

		if (!err) {
			unsigned short call;

			err = get_user(call, (unsigned short *)(ret-2));
			if (!err) {
				if ((mov & 0xF8) == 0xB8 &&
				    jmp == 0xE9 &&
				    (call & 0xF8FF) == 0xD0FF &&
				    (regs->eip == ((unsigned long*)regs)[trans[(call>>8) & 0x07]]))
				{
					((unsigned long *)regs)[trans[mov & 0x07]] = addr1;
					regs->eip += addr2 + 10;
					return 4;
				}
			}
		}
	}
#endif

	return 1; /* PaX in action */
}

static void pax_report_fault(struct pt_regs *regs)
{
	struct task_struct *tsk = current;
	struct mm_struct *mm = current->mm;
	char* buffer = (char*)__get_free_page(GFP_ATOMIC);
	char* path=NULL;
	unsigned long i;

	if (buffer) {
		struct vm_area_struct* vma;

		down_read(&mm->mmap_sem);
		vma = mm->mmap;
		while (vma) {
			if ((vma->vm_flags & VM_EXECUTABLE) && vma->vm_file) {
				break;
			}
			vma = vma->vm_next;
		}
		if (vma)
			path = d_path(vma->vm_file->f_dentry, vma->vm_file->f_vfsmnt, buffer, PAGE_SIZE);
		up_read(&mm->mmap_sem);
	}
	if (tsk->curr_ip)
		printk(KERN_ERR "PAX: From %u.%u.%u.%u: terminating task: %.930s(%.16s):%d, uid/euid: %u/%u, "
			"EIP: %08lX, ESP: %08lX\n", NIPQUAD(tsk->curr_ip),
			path, tsk->comm, tsk->pid, tsk->uid, tsk->euid, 
			regs->eip, regs->esp);
	else
		printk(KERN_ERR "PAX: terminating task: %.930s(%.16s):%d, uid/euid: %u/%u, "
			"EIP: %08lX, ESP: %08lX\n", path, tsk->comm, tsk->pid,
			tsk->uid, tsk->euid, regs->eip, regs->esp);

	if (buffer) free_page((unsigned long)buffer);
	printk(KERN_ERR "PAX: bytes at EIP: ");
	for (i = 0; i < 20; i++) {
		unsigned char c;
		if (get_user(c, (unsigned char*)(regs->eip+i))) {
			printk("<invalid address>.");
			break;
		}
		printk("%02x ", c);
	}
	printk("\n");
	do_coredump(SIGKILL, regs);
}
#endif

#ifdef CONFIG_GRKERNSEC_PAX_PAGEEXEC
/*
 * PaX: handle the extra page faults or pass it down to the original handler
 *
 * returns 0 when nothing special was detected
 *         1 when sigreturn trampoline (syscall) has to be emulated
 */
asmlinkage int pax_do_page_fault(struct pt_regs *regs, unsigned long error_code)
{
	struct mm_struct *mm = current->mm;
	unsigned long address;
	pte_t *pte;
	unsigned char pte_mask;
	int ret;

	__asm__("movl %%cr2,%0":"=r" (address));

	/* It's safe to allow irq's after cr2 has been saved */
	if (regs->eflags & X86_EFLAGS_IF)
		local_irq_enable();

	if (unlikely((error_code & 5) != 5 ||
		     address >= TASK_SIZE ||
		     !(current->flags & PF_PAX_PAGEEXEC)))
		return do_page_fault(regs, error_code, address);

	/* PaX: it's our fault, let's handle it if we can */

	/* PaX: take a look at read faults before acquiring any locks */
	if (unlikely((error_code == 5) && (regs->eip == address))) { 
		/* instruction fetch attempt from a protected page in user mode */
		ret = pax_handle_read_fault(regs);
		switch (ret) {
#ifdef CONFIG_GRKERNSEC_PAX_RANDEXEC
		case 5:
			return 0;
#endif

#ifdef CONFIG_GRKERNSEC_PAX_EMUTRAMP

		case 4:
			return 0;
		case 3:
		case 2: return 1;
#endif
		case 1:
		default:
			pax_report_fault(regs);
			do_exit(SIGKILL);
		}
	}

	pte_mask = _PAGE_ACCESSED | _PAGE_USER | ((error_code & 2) << (_PAGE_BIT_DIRTY-1));

again:
	spin_lock(&mm->page_table_lock);
	pte = pax_get_pte(mm, address);
	if (unlikely(!pte || !(pte_val(*pte) & _PAGE_PRESENT) || pte_exec(*pte))) {
		spin_unlock(&mm->page_table_lock);
		do_page_fault(regs, error_code, address);
		return 0;
	}

	if (unlikely((error_code == 7) && !pte_write(*pte))) {
		/* write attempt to a protected page in user mode */
		spin_unlock(&mm->page_table_lock);
		do_page_fault(regs, error_code, address);
		goto again;
	}

	/*
	 * PaX: fill DTLB with user rights and retry
	 */
	__asm__ __volatile__ (
		"orb %2,%1\n"
#if defined(CONFIG_M586) || defined(CONFIG_M586TSC)
/*   
 * PaX: let this uncommented 'invlpg' remind us on the behaviour of Intel's   
 * (and AMD's) TLBs. namely, they do not cache PTEs that would raise *any*
 * page fault when examined during a TLB load attempt. this is true not only
 * for PTEs holding a non-present entry but also present entries that will
 * raise a page fault (such as those set up by PaX, or the copy-on-write
 * mechanism). in effect it means that we do *not* need to flush the TLBs
 * for our target pages since their PTEs are simply not in the TLBs at all.
 * the best thing in omitting it is that we gain around 15-20% speed in 
 * fast path of the page fault handler and can get rid of tracing since we
 * can no longer flush unintended entries.
 */

		"invlpg %0\n"
#endif

		"testb $0,%0\n"
		"xorb %3,%1\n"
		:
		: "m" (*(char*)address), "m" (*(char*)pte) , "q" (pte_mask) , "i" (_PAGE_USER)
		: "memory", "cc");
	spin_unlock(&mm->page_table_lock);
	return 0;
}
#endif
