/* * * * * * * * * * * * * * * * * * * *
 * Main grsecurity header file
 * * * * * * * * * * * * * * * * * * * */

/* Because this header file is used by the other sections of the kernel
 * it defines external functions. The actual code in kernel/gracl.c
 * uses include/linux/gracl.h. We make sure that that code ignores our
 * extern declarations to avoid conflicts */

#ifndef GR_SECURITY_H
#define GR_SECURITY_H

#ifndef CONFIG_GRKERNSEC
#define gr_is_capable(cap)	1
#define gr_learn_resource(task, limit, wanted)	do {} while(0)
#define gr_handle_mmap(file, prot)	0
#define gr_handle_ptrace(child, request)	0
#define gr_check_hidden_task(task)	0
#define gr_pid_is_chrooted(p)	0
#define gr_copy_label(p)	
#define gr_handle_crash(task, sig)	do {} while(0)
#define grsec_enable_randid	0
#define grsec_enable_forkfail	0
#define grsec_enable_randping	0
#define grsec_enable_randsrc	0
#define grsec_enable_randrpc	0

static inline u16 ip_randomid(void)
{
	return 0;
}


#else /* CONFIG_GRKERNSEC */

#ifndef GR_ACL_H

#include <linux/dcache.h>
#include <linux/grdefs.h>
#include <linux/in.h>
#include <linux/net.h>

extern int gr_disable;
extern int gr_acl_is_enabled(void);
extern __u32 gr_search_file(const struct dentry *dentry, __u32 mode,
			    const struct vfsmount *mnt);
extern __u32 gr_check_root(const struct dentry * dentry,
			   const struct vfsmount * mnt, const __u32 mode);
extern void gr_set_proc_label(const struct dentry *dentry,
			      const struct vfsmount *mnt);
extern void gr_set_pax_flags(struct task_struct *task);
extern int gr_check_hidden_task(const struct task_struct *tsk);
extern int gr_check_protected_task(const struct task_struct *tsk);
extern void gr_copy_label(struct task_struct *tsk);
extern void gr_handle_delete(const ino_t ino, const kdev_t dev);
extern int gr_handle_mmap(const struct file * filp,
				 const unsigned long prot);
extern int gr_handle_ptrace(struct task_struct * task, const long request);
extern int gr_handle_ptrace_exec(const struct dentry *dentry, const struct vfsmount *mnt,
				 const char *filename);
extern void gr_handle_create(const struct dentry * dentry,
			     const struct vfsmount * mnt);
extern void gr_handle_crash(struct task_struct * task, const int sig);
extern int gr_check_crash_exec(const struct file * filp);
extern int gr_check_crash_uid(const uid_t uid);
extern int gr_handle_rename(struct inode * old_dir, struct inode * new_dir,
			     struct dentry * old_dentry, 
			     struct dentry * new_dentry,
			     struct vfsmount * mnt, const __u8 noreplace); 
extern int gr_search_socket(const int family, const int type, const int protocol);
extern int gr_search_connectbind(const int mode, const struct socket * sock,
				 const struct sockaddr_in * addr);
extern int gr_set_acls(const int type);
extern __u32 gr_check_create(const struct dentry *new_dentry, const struct dentry *parent,
			   const struct vfsmount *mnt, const __u32 mode);
extern int gr_is_capable(const int cap);
extern void gr_learn_resource(const struct task_struct * task, const int limit, 
					const unsigned long wanted);
#endif

#include <linux/grmsg.h>
#include <linux/binfmts.h>

extern __u16 ip_randomid(void);

extern int grsec_enable_link;
extern int grsec_enable_fifo;
extern int grsec_enable_execve;
extern int grsec_enable_forkbomb;
extern int grsec_forkbomb_gid;
extern int grsec_forkbomb_sec;
extern int grsec_forkbomb_max;
extern int grsec_enable_execlog;
extern int grsec_enable_signal;
extern int grsec_enable_forkfail;
extern int grsec_enable_time;
extern int grsec_enable_dmesg;
extern int grsec_enable_chroot_shmat;
extern int grsec_enable_chroot_findtask;
extern int grsec_enable_chroot_mount;
extern int grsec_enable_chroot_double;
extern int grsec_enable_chroot_pivot;
extern int grsec_enable_chroot_chdir;
extern int grsec_enable_chroot_chmod;
extern int grsec_enable_chroot_mknod;
extern int grsec_enable_chroot_fchdir;
extern int grsec_enable_chroot_nice;
extern int grsec_enable_chroot_execlog;
extern int grsec_enable_chroot_caps;
extern int grsec_enable_tpe;
extern int grsec_tpe_gid;
extern int grsec_enable_tpe_all;
extern int grsec_enable_sidcaps;
extern int grsec_enable_randpid;
extern int grsec_enable_randid;
extern int grsec_enable_randsrc;
extern int grsec_enable_randrpc;
extern int grsec_enable_randping;
extern int grsec_enable_socket_all;
extern int grsec_socket_all_gid;
extern int grsec_enable_socket_client;
extern int grsec_socket_client_gid;
extern int grsec_enable_socket_server;
extern int grsec_socket_server_gid;
extern int grsec_audit_gid;
extern int grsec_enable_group;
extern int grsec_enable_audit_ipc;
extern int grsec_enable_mount;
extern int grsec_enable_chdir;
extern int grsec_lock;

extern struct task_struct *child_reaper;

#define proc_is_chrooted(tsk_a)  ((tsk_a->fs->root->d_inode->i_dev != \
			  child_reaper->fs->root->d_inode->i_dev) || \
			  (tsk_a->fs->root->d_inode->i_ino != \
			  child_reaper->fs->root->d_inode->i_ino))

#define have_same_root(tsk_a,tsk_b) ((tsk_a->fs->root->d_inode->i_dev == \
			  tsk_b->fs->root->d_inode->i_dev) && \
			  (tsk_a->fs->root->d_inode->i_ino == \
			  tsk_b->fs->root->d_inode->i_ino))

#define DEFAULTSECARGS current->comm, current->pid, current->uid, \
		       current->euid, current->p_pptr->comm, \
		       current->p_pptr->pid, current->p_pptr->uid, \
		       current->p_pptr->euid

#define GR_CHROOT_CAPS ( \
	CAP_TO_MASK(CAP_FOWNER) | CAP_TO_MASK(CAP_SYS_RESOURCE) | \
	CAP_TO_MASK(CAP_LINUX_IMMUTABLE) | CAP_TO_MASK(CAP_NET_ADMIN) | \
	CAP_TO_MASK(CAP_SYS_MODULE) | CAP_TO_MASK(CAP_SYS_RAWIO) | \
	CAP_TO_MASK(CAP_SYS_PACCT) | CAP_TO_MASK(CAP_SYS_ADMIN) | \
	CAP_TO_MASK(CAP_SYS_BOOT) | CAP_TO_MASK(CAP_SYS_TIME) | \
	CAP_TO_MASK(CAP_NET_RAW) | CAP_TO_MASK(CAP_SYS_TTY_CONFIG) | \
	CAP_TO_MASK(CAP_IPC_OWNER))

#define GR_BIND 0x01
#define GR_CONNECT 0x02

void gr_handle_exec_args(struct linux_binprm * bprm, char ** argv);
int gr_tpe_allow(struct file * file);
int gr_tpe_all_allow(struct file * file);
int gr_pid_is_chrooted(struct task_struct *p);
int gr_chroot_fchdir(struct dentry *dentry, struct vfsmount *mnt);
void gr_handle_alertkill(void);

#define GR_FLOODTIME CONFIG_GRKERNSEC_FLOODTIME
#define GR_FLOODBURST CONFIG_GRKERNSEC_FLOODBURST

#define security_alert_good(normal_msg,flood_msg,args...) \
({ \
	static unsigned long warning_time = 0, no_flood_yet = 0; \
	static spinlock_t security_alert_lock = SPIN_LOCK_UNLOCKED; \
	\
	spin_lock(&security_alert_lock); \
	\
	if (!warning_time || jiffies - warning_time > GR_FLOODTIME * HZ) { \
	    warning_time = jiffies; no_flood_yet = 0; \
	    if (current->curr_ip) \
		printk(KERN_ALERT "grsec: From %u.%u.%u.%u: " normal_msg "\n", NIPQUAD(current->curr_ip) , ## args); \
	    else \
	    	printk(KERN_ALERT "grsec: " normal_msg "\n" , ## args); \
	} else if((jiffies - warning_time < GR_FLOODTIME * HZ) && (no_flood_yet < GR_FLOODBURST)) { \
	    no_flood_yet++; \
	    if (current->curr_ip) \
		printk(KERN_ALERT "grsec: From %u.%u.%u.%u: " normal_msg "\n", NIPQUAD(current->curr_ip) , ## args); \
	    else \
	    	printk(KERN_ALERT "grsec: " normal_msg "\n" , ## args); \
	} else if (no_flood_yet == GR_FLOODBURST) { \
	    warning_time = jiffies; no_flood_yet++; \
	    printk(KERN_ALERT "grsec: more " flood_msg \
		    ", logging disabled for %d seconds\n",GR_FLOODTIME); \
	} \
	\
	spin_unlock(&security_alert_lock); \
})

#define security_alert(normal_msg,flood_msg,args...) \
({ \
	static unsigned long warning_time = 0, no_flood_yet = 0; \
	static spinlock_t security_alert_lock = SPIN_LOCK_UNLOCKED; \
	\
	spin_lock(&security_alert_lock); \
	\
	if (!warning_time || jiffies - warning_time > GR_FLOODTIME * HZ) { \
	    warning_time = jiffies; no_flood_yet = 0; \
	    if (current->curr_ip) \
		printk(KERN_ALERT "grsec: From %u.%u.%u.%u: " normal_msg "\n", NIPQUAD(current->curr_ip) , ## args); \
	    else \
	    	printk(KERN_ALERT "grsec: " normal_msg "\n" , ## args); \
	} else if((jiffies - warning_time < GR_FLOODTIME * HZ) && (no_flood_yet < GR_FLOODBURST)) { \
	    no_flood_yet++; \
	    if (current->curr_ip) \
		printk(KERN_ALERT "grsec: From %u.%u.%u.%u: " normal_msg "\n", NIPQUAD(current->curr_ip) , ## args); \
	    else \
	    	printk(KERN_ALERT "grsec: " normal_msg "\n" , ## args); \
	} else if (no_flood_yet == GR_FLOODBURST) { \
	    warning_time = jiffies; no_flood_yet++; \
	    printk(KERN_ALERT "grsec: more " flood_msg \
		    ", logging disabled for %d seconds\n",GR_FLOODTIME); \
	} \
	\
	gr_handle_alertkill(); \
	spin_unlock(&security_alert_lock); \
})

#define security_audit(normal_msg,args...) \
({ \
	if (current->curr_ip) \
		printk(KERN_INFO "grsec: From %u.%u.%u.%u: " normal_msg "\n", \
		       NIPQUAD(current->curr_ip) , ## args); \
	else \
		printk(KERN_INFO "grsec: " normal_msg "\n", ## args); \
})

#define security_learn(normal_msg,args...) \
	printk(KERN_INFO "grsec: " normal_msg "\n", ## args)

#define security_debug(normal_msg,args...) \
	printk(KERN_DEBUG "grsec: " normal_msg "\n", ## args)

#endif /* CONFIG_GRKERNSEC */
#endif /* GR_SECURITY_H */
