#ifndef _LINUX_CONDSCHED_H
#define _LINUX_CONDSCHED_H

#ifndef __LINUX_COMPILER_H
#include <linux/compiler.h>
#endif

#ifndef __ASSEMBLY__
#define conditional_schedule()				\
do {							\
	if (unlikely(current->need_resched)) {		\
		__set_current_state(TASK_RUNNING);	\
		schedule();				\
	}						\
} while(0)
#endif

#endif
