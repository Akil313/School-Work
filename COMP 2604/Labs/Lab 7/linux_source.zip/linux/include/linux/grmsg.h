#define DEFAULTSECMSG "(%.16s:%d) UID(%d) EUID(%d), parent (%.16s:%d) UID(%d) EUID(%d)"
#define GR_PTRACE_ACL_MSG "denied ptrace of (%.16s:%d) by " DEFAULTSECMSG
#define GR_PTRACE_ACL_FLD "denied ptraces"
#define GR_SHMAT_ACL_MSG "denied attach of shared memory of UID %u, PID %d, ID %u by " DEFAULTSECMSG
#define GR_SHMAT_ACL_FLD "denied shared memory attaches"
#define GR_SHMAT_CHROOT_MSG "denied attach of shared memory outside of chroot jail by " DEFAULTSECMSG
#define GR_SHMAT_CHROOT_FLD "denied shared memory attaches in chroot"
#define GR_KMEM_MSG "attempted open of /dev/kmem by " DEFAULTSECMSG
#define GR_KMEM_FLD "attempted kmem opens"
#define GR_PORT_OPEN_MSG "attempted open of /dev/port by " DEFAULTSECMSG
#define GR_PORT_OPEN_FLD "attempted port opens"
#define GR_MEM_WRITE_MSG "attempted write of /dev/mem by " DEFAULTSECMSG
#define GR_MEM_WRITE_FLD "attempted mem writes"
#define GR_MEM_MMAP_MSG "attempted mmap of /dev/mem by " DEFAULTSECMSG
#define GR_MEM_MMAP_FLD "attempted mem mmaps"
#define GR_SYMLINK_MSG "not following symlink (%.30s/%.30s) of [%.32s]:%lu owned by %d.%d by " DEFAULTSECMSG
#define GR_SYMLINK_FLD "symlinks not followed"
#define GR_LEARN_AUDIT_MSG "LEARN:%d:%lu:%lu:%lu:%.950s:%lu"
#define GR_HIDDEN_ACL_MSG "attempt to access hidden file [%.32s:%lu] by " DEFAULTSECMSG
#define GR_HIDDEN_ACL_FLD "hidden file access attempts"
#define GR_OPEN_ACL_MSG "attempt to open %.950s for%s%s by " DEFAULTSECMSG
#define GR_OPEN_ACL_FLD "file open attempts"
#define GR_FIFO_MSG "denied writing FIFO (%.32s/%.32s) of %d.%d by " DEFAULTSECMSG
#define GR_FIFO_FLD "writes into a FIFO denied"
#define GR_MKNOD_CHROOT_MSG "refused attempt to mknod(%c:%.32s) (%.30s) from chroot jail [%.32s:%lu] owned by %d %d by " DEFAULTSECMSG
#define GR_MKNOD_CHROOT_FLD "mknods in chroot denied"
#define GR_MKNOD_ACL_MSG "attempt to mknod %.950s by " DEFAULTSECMSG
#define GR_MKNOD_ACL_FLD "mknod attempts"
#define GR_UNIXCONNECT_ACL_MSG "attempt to connect to the unix domain socket %.950s by " DEFAULTSECMSG
#define GR_UNIXCONNECT_ACL_FLD "unix domain connect attempts"
#define GR_MKDIR_ACL_MSG "attempt to mkdir %.950s by " DEFAULTSECMSG
#define GR_MKDIR_ACL_FLD "mkdir attempts"
#define GR_RMDIR_ACL_MSG "attempt to rmdir %.950s by " DEFAULTSECMSG
#define GR_RMDIR_ACL_FLD "rmdir attempts"
#define GR_UNLINK_ACL_MSG "attempt to unlink %.950s by " DEFAULTSECMSG
#define GR_UNLINK_ACL_FLD "unlink attempts"
#define GR_SYMLINK_ACL_MSG "attempt to symlink %.950s to %.950s by " DEFAULTSECMSG
#define GR_SYMLINK_ACL_FLD "symlink attempts"
#define GR_HARDLINK_MSG "denied hardlink of %.30s (owned by %d.%d) to %.30s for " DEFAULTSECMSG
#define GR_HARDLINK_FLD "denied hardlinks"
#define GR_LINK_ACL_MSG "attempt to link %.950s to %.950s by " DEFAULTSECMSG
#define GR_LINK_ACL_FLD "attempted links"
#define GR_RENAME_ACL_MSG "attempt to rename %.950s to %.950s by " DEFAULTSECMSG
#define GR_RENAME_ACL_FLD "rename attempts"
#define GR_PTRACE_EXEC_ACL_MSG "denied ptrace of [%.32s:%lu] (%.16s) by " DEFAULTSECMSG
#define GR_PTRACE_EXEC_ACL_FLD "denied ptraces"
#define GR_NPROC_MSG "attempt to overstep process limit by " DEFAULTSECMSG
#define GR_NPROC_FLD "proc limit overstep"
#define GR_EXEC_ACL_MSG "denying execution of %.950s by " DEFAULTSECMSG
#define GR_EXEC_ACL_FLD "file exec attempts"
#define GR_EXEC_TPE_MSG "denied exec of %.32s by " DEFAULTSECMSG " reason: untrusted"
#define GR_EXEC_TPE_FLD "denied execs"
#define GR_SEGVSTART_ACL_MSG "Possible exploit bruteforcing on " DEFAULTSECMSG " Banning uid %u from login for %lu seconds"
#define GR_SEGVSTART_ACL_FLD "possible exploit bruteforcing"
#define GR_SEGVNOSUID_ACL_MSG "Possible exploit bruteforcing on " DEFAULTSECMSG " Banning execution of [%.16s:%lu] for %lu seconds"
#define GR_SEGVNOSUID_ACL_FLD "possible exploit bruteforcing"
#define GR_MOUNT_CHROOT_MSG "denied attempt to mount (%.30s) as %.64s from chroot jail (%.32s:%lu) of %d.%d by " DEFAULTSECMSG
#define GR_MOUNT_CHROOT_FLD "denied mounts in chroot"
#define GR_PIVOT_CHROOT_MSG "denied attempt to pivot_root from chroot jail [%.32s:%lu] of %d.%d by " DEFAULTSECMSG
#define GR_PIVOT_CHROOT_FLD "denied pivot_roots in chroot"
#define GR_TRUNCATE_ACL_MSG "attempted to truncate file [%.32s:%lu] by " DEFAULTSECMSG
#define GR_TRUNCATE_ACL_FLD "file truncate attempts"
#define GR_ATIME_ACL_MSG "attempted to change access time for file [%.32s:%lu] by " DEFAULTSECMSG
#define GR_ATIME_ACL_FLD "file access time change attempts"
#define GR_ACCESS_ACL_MSG "attempted to access file [%.32s:%lu] by " DEFAULTSECMSG
#define GR_ACCESS_ACL_FLD "file access attempts"
#define GR_CHDIR_ACL_MSG "Attempted to chdir to directory [%.32s:%lu] by " DEFAULTSECMSG
#define GR_CHDIR_ACL_FLD "chdir attempts"
#define GR_FCHDIR_ACL_MSG "attempted to fchdir to directory [%.32s:%lu] by " DEFAULTSECMSG
#define GR_FCHDIR_ACL_FLD "fchdir attempts"
#define GR_FCHDIR_AUDIT_MSG "fchdir(%d) to %.64s by " DEFAULTSECMSG
#define GR_CHROOT_CHROOT_MSG "denied attempt to chroot() from (%.32s:%lu) to (%.30s) by " DEFAULTSECMSG
#define GR_CHROOT_CHROOT_FLD "double chroot denied"
#define GR_FCHMOD_ACL_MSG "Attempt to fchmod file [%.32s:%lu] by " DEFAULTSECMSG
#define GR_FCHMOD_ACL_FLD "fchmod attempts"
#define GR_FCHMOD_CHROOT_MSG "denied attempt to fchmod +s (%.32s:%lu) owned by %d.%d to mode 0%07o from chroot jail (%.32s:%lu) of %d.%d by " DEFAULTSECMSG
#define GR_FCHMOD_CHROOT_FLD "denied fchmod +s in chroot"
#define GR_CHMOD_ACL_MSG "Attempt to chmod file [%.32s:%lu] %.950s by " DEFAULTSECMSG
#define GR_CHMOD_ACL_FLD "chmod attempts"
#define GR_CHMOD_CHROOT_MSG "denied attempt to chmod +s (%.32s:%lu) (%.30s) owned by %d.%d to mode 0%07o from chroot jail (%.32s:%lu) of %d.%d by " DEFAULTSECMSG
#define GR_CHMOD_CHROOT_FLD "denied chmod +s in chroot"
#define GR_CHROOT_FCHDIR_MSG "Attempted fchdir outside of chroot to %.16s by " DEFAULTSECMSG
#define GR_CHROOT_FCHDIR_FLD "attempted fchdirs"
#define GR_CHOWN_ACL_MSG "Attempt to chown file [%.32s:%lu] to %d.%d by " DEFAULTSECMSG
#define GR_CHOWN_ACL_FLD "chown attempts"
#define GR_WRITLIB_ACL_MSG "attempt to load writable library [%.32s:%lu] by " DEFAULTSECMSG
#define GR_WRITLIB_ACL_FLD "writable library loads"
#define GR_INITF_ACL_MSG "init_variables() failed %s"
#define GR_INITF_ACL_FLD "init_variables() failures"
#define GR_DISABLED_ACL_MSG "Error loading %s, trying to run kernel with acls disabled. To disable acls at startup use <kernel image name> gracl=off from your boot loader"
#define GR_DISABLED_ACL_FLD "error loading acls"
#define GR_PROC_ACL_MSG "Proc handler: being fed garbage %d bytes sent %d required"
#define GR_PROC_ACL_FLD "proc garbage"
#define GR_SHUTS_ACL_MSG "shutdown auth success for " DEFAULTSECMSG
#define GR_SHUTS_ACL_FLD "shutdown successes"
#define GR_SHUTF_ACL_MSG "shutdown auth failure for " DEFAULTSECMSG
#define GR_SHUTF_ACL_FLD "shutdown failures"
#define GR_SHUTI_ACL_MSG "ignoring shutdown for disabled acl for " DEFAULTSECMSG
#define GR_SHUTI_ACL_FLD "ignored shutdowns"
#define GR_SEGVMODS_ACL_MSG "segvmod auth success for " DEFAULTSECMSG
#define GR_SEGVMODS_ACL_FLD "segvmod successes"
#define GR_SEGVMODF_ACL_MSG "segvmod auth failure for " DEFAULTSECMSG
#define GR_SEGVMODF_ACL_FLD "segvmod failures"
#define GR_SEGVMODI_ACL_MSG "ignoring segvmod for disabled acl for " DEFAULTSECMSG
#define GR_SEGVMODI_ACL_FLD "ignored segvmods"
#define GR_ENABLEI_ACL_MSG "%s at boot time, ignoring load request"
#define GR_ENABLEI_ACL_FLD "attempts to load gracl when disabled on boot"
#define GR_ENABLE_ACL_MSG "Loaded %s"
#define GR_ENABLE_ACL_FLD "grsecurity loads"
#define GR_ENABLEF_ACL_MSG "Unable to load %s for " DEFAULTSECMSG " ACL system may already be enabled."
#define GR_ENABLEF_ACL_FLD "enable failures"
#define GR_RELOADI_ACL_MSG "Ignoring reload request for disabled ACL"
#define GR_RELOADI_ACL_FLD "attempts to reload gracl when disabled"
#define GR_RELOAD_ACL_MSG "Reloaded %s"
#define GR_RELOAD_ACL_FLD "grsecurity reloads"
#define GR_RELOADF_ACL_MSG "Failed reload of %s for " DEFAULTSECMSG
#define GR_RELOADF_ACL_FLD "reload failures"
#define GR_ADMINI_ACL_MSG "Ignoring change to admin mode for disabled acl for " DEFAULTSECMSG
#define GR_ADMINI_ACL_FLD "ignored admin"
#define GR_ADMINS_ACL_MSG "successful change to admin mode by " DEFAULTSECMSG
#define GR_ADMINS_ACL_FLD "changes to admin mode"
#define GR_ADMINL_ACL_MSG "admin mode exited by " DEFAULTSECMSG
#define GR_ADMINL_ACL_FLD "leaving admin mode"
#define GR_ADMINF_ACL_MSG "admin auth failure for " DEFAULTSECMSG
#define GR_ADMINF_ACL_FLD "admin failures"
#define GR_INVMODE_ACL_MSG "Invalid mode %d by " DEFAULTSECMSG
#define GR_INVMODE_ACL_FLD "invalid modes"
#define GR_MAXPW_ACL_MSG "Maximum pw attempts reached (%d), locking password authentication"
#define GR_MAXPW_ACL_FLD "password attempts failed"
#define GR_PRIORITY_CHROOT_MSG "attempted priority change of process (%.16s:%d) by " DEFAULTSECMSG
#define GR_PRIORITY_CHROOT_FLD "attempted priority changes"
#define GR_CAPSET_CHROOT_MSG "denied capset of (%.16s:%d) within chroot jail [%.32s:%lu] by " DEFAULTSECMSG
#define GR_CAPSET_CHROOT_FLD "denied chroot capsets"
#define GR_FAILFORK_MSG "failed fork with errno %d by " DEFAULTSECMSG
#define GR_FAILFORK_FLD "failed forks"
#define GR_NICE_CHROOT_MSG "attempted priority change by " DEFAULTSECMSG
#define GR_NICE_CHROOT_FLD "attempted priority changes"
#define GR_UNISIGLOG_MSG "signal %d sent to " DEFAULTSECMSG
#define GR_UNISIGLOG_FLD "signal warnings"
#define GR_DUALSIGLOG_MSG "signal %d sent to " DEFAULTSECMSG " by " DEFAULTSECMSG
#define GR_DUALSIGLOG_FLD "signal warnings"
#define GR_SIG_ACL_MSG "Attempted send of signal %d to protected task " DEFAULTSECMSG " by " DEFAULTSECMSG
#define GR_SIG_ACL_FLD "signals to protected processes"
#define GR_SYSCTL_MSG "attempt to modify grsecurity sysctl value : %.32s by " DEFAULTSECMSG
#define GR_SYSCTL_FLD "attempted sysctl changes"
#define GR_SYSCTL_ACL_MSG "attempt to sysctl() %.32s for%s%s by " DEFAULTSECMSG
#define GR_SYSCTL_ACL_FLD "attempted sysctl accesses"
#define GR_TIME_MSG "time set by " DEFAULTSECMSG
#define GR_TIME_FLD "time sets"
#define GR_DEFACL_MSG "Fatal: Unable to find ACL for (%.16s:%d)"
#define GR_DEFACL_FLD "default acl errors"
#define GR_MMAP_ACL_MSG "attempt to mmap [%.32s:%lu] %.30s executable by " DEFAULTSECMSG
#define GR_MMAP_ACL_FLD "mmap exec attempts"
#define GR_SOCK_MSG "attempted socket(%d,%d,%d) by " DEFAULTSECMSG
#define GR_SOCK_FLD "attempted sockets"
#define GR_BIND_MSG "attempted bind() by " DEFAULTSECMSG
#define GR_BIND_FLD "attempted binds"
#define GR_CONNECT_MSG "attempted connect() to fd %d by " DEFAULTSECMSG
#define GR_CONNECT_FLD "attempted connects"
#define GR_BIND_ACL_MSG "attempted bind to %u.%u.%u.%u port %u sock type %u protocol %u by " DEFAULTSECMSG
#define GR_BIND_ACL_FLD "attempted binds"
#define GR_CONNECT_ACL_MSG "attempted connect to %u.%u.%u.%u port %u sock type %u protocol %u by " DEFAULTSECMSG
#define GR_CONNECT_ACL_FLD "attempted connects"
#define GR_IP_LEARN_MSG "LEARN:%d:%lu:%u.%u.%u.%u:%u:%u:%u:%u"
#define GR_EXEC_CHROOT_MSG "exec of %.64s within chroot jail [%.32s:%lu] by process " DEFAULTSECMSG
#define GR_CAP_ACL_MSG "use of %s denied for " DEFAULTSECMSG
#define GR_CAP_ACL_FLD "denied capabilities"
#define GR_REMOUNT_AUDIT_MSG "remount of %.30s by " DEFAULTSECMSG
#define GR_UNMOUNT_AUDIT_MSG "unmount of %.30s by " DEFAULTSECMSG
#define GR_MOUNT_AUDIT_MSG "mount %.30s to %.64s by " DEFAULTSECMSG
#define GR_CHDIR_AUDIT_MSG "chdir(\"%.64s\") by " DEFAULTSECMSG
#define GR_EXEC_AUDIT_MSG "exec of [%.32s:%lu] (%.63s) by " DEFAULTSECMSG
#define GR_MSGQ_AUDIT_MSG "message queue created by " DEFAULTSECMSG
#define GR_MSGQR_AUDIT_MSG "message queue of uid:%d euid:%d removed by " DEFAULTSECMSG
#define GR_SEM_AUDIT_MSG "semaphore created by " DEFAULTSECMSG
#define GR_SEMR_AUDIT_MSG "semaphore of uid:%d euid:%d removed by " DEFAULTSECMSG
#define GR_SHM_AUDIT_MSG "shared memory of size %d created by " DEFAULTSECMSG
#define GR_SHMR_AUDIT_MSG "shared memory of uid:%d euid:%d removed by " DEFAULTSECMSG
#define GR_ACLINIT_DEBUG_MSG "got %.3s at startup"
#define GR_ACLNCOLL_DEBUG_MSG "Hey, I had a name entry collision(I am %.425s and I collided with %.425s)"
#define GR_ACLOCOLL_DEBUG_MSG "Hey, I had an acl object label collision (I am %lu %d)"
#define GR_ACLSCOLL_DEBUG_MSG "Hey, I had an acl subject label collision (I am %lu %d )"
#define GR_LISTNAMES_DEBUG_MSG "Name Entry pos %lu has inode %lu dev %.32s name %.950s"
#define GR_LISTPROCSS_DEBUG_MSG "MAC Subject pos %lu has inode %lu dev %.32s mode %x pos %lu"
#define GR_LISTPROCSO_DEBUG_MSG "MAC Object pos %lu has inode %lu dev %.32s mode %x parent %lu"
#define GR_LISTACLS1_DEBUG_MSG "Iterating through received table\n"
#define GR_LISTACLS2_DEBUG_MSG "Note: there should be %lu acl subject entries and %lu acl object entries"
#define GR_LISTACLSS_DEBUG_MSG "Subject label %.950s position %lu has inode %lu device %d"
#define GR_LISTACLSO_DEBUG_MSG "Object label %.950s position %lu has inode %lu device %d"
#define GR_OBJDEL_DEBUG_MSG "Acl Object [%.32s:%lu] pos %lu deleted"
#define GR_SUBJDEL_DEBUG_MSG "ACL subject [%.32s:%lu] deleted"
#define GR_SUBJREC_DEBUG_MSG "Process Subj ACL %.950s recreated"
#define GR_OBJREC_DEBUG_MSG "Process Obj ACL %.950s pos %lu recreated"
#define GR_RESOURCE_MSG "attempted resource overstep by requesting %lu for %.16s against limit %lu by " DEFAULTSECMSG
#define GR_RESOURCE_FLD "attempted resource overstepping"
