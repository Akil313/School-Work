#ifndef _LINUX_MALLOC_H
#define _LINUX_MALLOC_H

#warning linux/malloc.h is deprecated, use linux/slab.h instead.

#include <linux/slab.h>
#endif /* _LINUX_MALLOC_H */
